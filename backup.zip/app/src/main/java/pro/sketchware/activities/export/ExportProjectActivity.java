package pro.sketchware.activities.export;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import com.airbnb.lottie.LottieAnimationView;
import pro.sketchware.activities.base.BaseAppCompatActivity;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import pro.sketchware.third_party.kellinwood.security.zipsigner.ZipSigner;
import pro.sketchware.third_party.kellinwood.security.zipsigner.optional.CustomKeySigner;
import pro.sketchware.third_party.kellinwood.security.zipsigner.optional.LoadKeystoreException;
import pro.sketchware.core.build.compiler.KotlinCompilerBridge;
import pro.sketchware.core.project.ProguardHandler;
import pro.sketchware.core.project.StringfogHandler;
import pro.sketchware.util.Helper;
import pro.sketchware.core.build.BuildProgressReceiver;
import pro.sketchware.util.library.BuiltInLibraries;
import pro.sketchware.core.build.compiler.AppBundleCompiler;
import pro.sketchware.dialogs.GetKeyStoreCredentialsDialog;
import pro.sketchware.util.TestkeySignBridge;
import org.spongycastle.jce.provider.BouncyCastleProvider;

import pro.sketchware.R;
import pro.sketchware.core.async.BackgroundTasks;
import pro.sketchware.util.io.EncryptedFileUtil;
import pro.sketchware.core.project.LibraryManager;
import pro.sketchware.util.MapValueHelper;
import pro.sketchware.core.build.ProjectBuilder;
import pro.sketchware.core.project.ProjectDataStore;
import pro.sketchware.core.project.ProjectFileManager;
import pro.sketchware.core.build.ProjectFilePaths;
import pro.sketchware.core.project.ProjectListManager;
import pro.sketchware.core.project.ResourceManager;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.core.async.TaskHost;
import pro.sketchware.core.validation.VersionCodeValidator;
import pro.sketchware.util.io.ZipUtil;
import pro.sketchware.util.FilePathUtil;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.SketchwareUtil;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;

public class ExportProjectActivity extends BaseAppCompatActivity {

    private final EncryptedFileUtil file_utility = new EncryptedFileUtil();
    /**
     * /sketchware/signed_apk
     */
    private String signed_apk_postfix;
    /**
     * /sketchware/export_src
     */
    private String export_src_postfix;
    /**
     * /sdcard/sketchware/export_src
     */
    private String export_src_full_path;
    private String export_src_filename;
    private String sc_id;
    private HashMap<String, Object> sc_metadata = null;
    private ProjectFilePaths project_metadata = null;
    private BuildingAsyncTask currentBuildingTask;

    private Button sign_apk_button;
    private Button export_aab_button;
    private Button export_source_button;
    private TextView sign_apk_output_path;
    private Button export_source_send_button;
    private LinearLayout sign_apk_output_stage;
    private TextView export_source_output_path;
    private LinearLayout export_source_output_stage;
    private com.airbnb.lottie.LottieAnimationView sign_apk_loading_anim;
    private com.airbnb.lottie.LottieAnimationView export_source_loading_anim;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.export_project);

        ImageView sign_apk_ic = findViewById(R.id.sign_apk_ic);
        ImageView export_aab_ic = findViewById(R.id.export_aab_ic);
        TextView sign_apk_title = findViewById(R.id.sign_apk_title);
        sign_apk_button = findViewById(R.id.sign_apk_button);
        ImageView export_source_ic = findViewById(R.id.export_source_ic);
        TextView export_aab_title = findViewById(R.id.export_aab_title);
        export_aab_button = findViewById(R.id.export_aab_button);
        TextView export_source_title = findViewById(R.id.export_source_title);
        sign_apk_output_path = findViewById(R.id.sign_apk_output_path);
        export_source_button = findViewById(R.id.export_source_button);
        sign_apk_output_stage = findViewById(R.id.sign_apk_output_stage);
        sign_apk_loading_anim = findViewById(R.id.sign_apk_loading_anim);
        export_source_output_path = findViewById(R.id.export_source_output_path);
        export_source_send_button = findViewById(R.id.export_source_send_button);
        export_source_output_stage = findViewById(R.id.export_source_output_stage);
        export_source_loading_anim = findViewById(R.id.export_source_loading_anim);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        findViewById(R.id.layout_main_logo).setVisibility(View.GONE);
        getSupportActionBar().setTitle(Helper.getResString(R.string.myprojects_export_project_actionbar_title));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowTitleEnabled(true);
        toolbar.setNavigationOnClickListener(Helper.getBackPressedClickListener(this));

        if (savedInstanceState == null) {
            sc_id = getIntent().getStringExtra("sc_id");
        } else {
            sc_id = savedInstanceState.getString("sc_id");
        }

        sc_metadata = ProjectListManager.getProjectById(sc_id);
        project_metadata = new ProjectFilePaths(getApplicationContext(), SketchwarePaths.getMyscPath(sc_id), sc_metadata);

        initializeOutputDirectories();
        initializeSignApkViews();
        initializeExportSrcViews();
        initializeAppBundleExportViews();
    }

    @Override
    public void onDestroy() {
        if (currentBuildingTask != null) {
            currentBuildingTask.cancelBuild();
            currentBuildingTask = null;
        }
        dismissProgressDialog();
        super.onDestroy();
        if (sign_apk_loading_anim.isAnimating()) {
            sign_apk_loading_anim.cancelAnimation();
        }
        if (export_source_loading_anim.isAnimating()) {
            export_source_loading_anim.cancelAnimation();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        savedInstanceState.putString("sc_id", sc_id);
        super.onSaveInstanceState(savedInstanceState);
    }

    /**
     * Sets exported signed APK file path texts' content.
     */
    private void showSignedApkOutput(String filePath) {
        sign_apk_output_stage.setVisibility(View.VISIBLE);
        sign_apk_button.setVisibility(View.GONE);
        if (sign_apk_loading_anim.isAnimating()) {
            sign_apk_loading_anim.cancelAnimation();
        }
        sign_apk_loading_anim.setVisibility(View.GONE);
        sign_apk_output_path.setText(signed_apk_postfix + File.separator + filePath);
        SketchwareUtil.toast(Helper.getResString(R.string.sign_apk_title_export_apk_file));
    }

    private String exportSrc() throws IOException {
        FileUtil.deleteFile(project_metadata.projectMyscPath);

        ProjectFileManager hCVar = new ProjectFileManager(sc_id);
        ResourceManager kCVar = new ResourceManager(sc_id);
        ProjectDataStore eCVar = new ProjectDataStore(sc_id);
        LibraryManager iCVar = new LibraryManager(sc_id);
        hCVar.loadFromData();
        kCVar.loadFromData();
        eCVar.loadViewFromData();
        eCVar.loadLogicFromData();
        iCVar.loadFromData();

        /* Extract project type template */
        project_metadata.extractAssetsToRes(getApplicationContext(), SketchwarePaths.getResourceZipPath(VersionCodeValidator.isValid(sc_id) ? "600" : sc_id));

        /* Start generating project files */
        ProjectBuilder builder = new ProjectBuilder(this, project_metadata);
        project_metadata.initializeMetadata(iCVar, hCVar, eCVar, ProjectFilePaths.ExportType.ANDROID_STUDIO);
        builder.buildBuiltInLibraryInformation();
        project_metadata.generateProjectFiles(hCVar, eCVar, iCVar, builder.getBuiltInLibraryManager());
        if (MapValueHelper.get(ProjectListManager.getProjectById(sc_id), "custom_icon")) {
            project_metadata.copyMipmapFolder(SketchwarePaths.getIconsPath() + File.separator + sc_id + File.separator + "mipmaps");
            if (MapValueHelper.get(ProjectListManager.getProjectById(sc_id), "isIconAdaptive", false)) {
                project_metadata.createLauncherIconXml("""
                        <?xml version="1.0" encoding="utf-8"?>
                        <adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android" >
                        <background android:drawable="@mipmap/ic_launcher_background"/>
                        <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
                        <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>
                        </adaptive-icon>""");
            }
        }
        project_metadata.deleteValuesV21Directory();
        kCVar.copyImagesToDir(project_metadata.resDirectoryPath + File.separator + "drawable-xhdpi");
        kCVar.copySoundsToDir(project_metadata.resDirectoryPath + File.separator + "raw");
        kCVar.copyFontsToDir(project_metadata.assetsPath + File.separator + "fonts");
        project_metadata.cleanBuildCache();

        /* It makes no sense that those methods aren't static */
        FilePathUtil util = new FilePathUtil();
        File pathJava = new File(util.getPathJava(sc_id));
        File pathResources = new File(util.getPathResource(sc_id));
        File pathAssets = new File(util.getPathAssets(sc_id));
        File pathNativeLibraries = new File(util.getPathNativelibs(sc_id));

        if (pathJava.exists()) {
            FileUtil.copyDirectory(pathJava, new File(project_metadata.javaFilesPath + File.separator + project_metadata.packageNameAsFolders));
        }
        if (pathResources.exists()) {
            FileUtil.copyDirectory(pathResources, new File(project_metadata.resDirectoryPath));
        }
        String pathProguard = util.getPathProguard(sc_id);
        if (FileUtil.isExistFile(pathProguard)) {
            FileUtil.copyFile(pathProguard, project_metadata.proguardFilePath);
        }
        if (pathAssets.exists()) {
            FileUtil.copyDirectory(pathAssets, new File(project_metadata.assetsPath));
        }
        if (pathNativeLibraries.exists()) {
            FileUtil.copyDirectory(pathNativeLibraries, new File(project_metadata.generatedFilesPath, "jniLibs"));
        }

        ArrayList<String> toCompress = new ArrayList<>();
        toCompress.add(project_metadata.projectMyscPath);
        String exportedFilename = MapValueHelper.getString(sc_metadata, "my_ws_name") + ".zip";

        String exportedSourcesZipPath = SketchwarePaths.getSketchwarePath() + File.separator + "export_src" + File.separator + exportedFilename;
        if (file_utility.exists(exportedSourcesZipPath)) {
            file_utility.deleteFileByPath(exportedSourcesZipPath);
        }

        ArrayList<String> toExclude = new ArrayList<>();
        if (!new File(new FilePathUtil().getPathJava(sc_id) + File.separator + "SketchApplication.java").exists()) {
            toExclude.add("SketchApplication.java");
        }
        toExclude.add("DebugActivity.java");

        new ZipUtil().createZipFile(exportedSourcesZipPath, toCompress, toExclude);
        project_metadata.prepareBuildDirectories();
        return exportedFilename;
    }

    private void initializeAppBundleExportViews() {
        export_aab_button.setOnClickListener(view -> {
            MaterialAlertDialogBuilder confirmationDialog = new MaterialAlertDialogBuilder(this);
            confirmationDialog.setTitle(Helper.getResString(R.string.export_title_important_note));
            confirmationDialog.setMessage(Helper.getResString(R.string.export_aab_sign_note));
            confirmationDialog.setIcon(R.drawable.ic_mtrl_info);

            confirmationDialog.setPositiveButton(Helper.getResString(R.string.export_btn_understood), (v, which) -> {
                showAabSigningDialog();
                v.dismiss();
            });
            confirmationDialog.show();
        });
    }

    private void showAabSigningDialog() {
        GetKeyStoreCredentialsDialog credentialsDialog = new GetKeyStoreCredentialsDialog(this,
                R.drawable.ic_mtrl_key, Helper.getResString(R.string.export_aab_sign_dialog_title), Helper.getResString(R.string.export_aab_sign_dialog_desc));
        credentialsDialog.setListener(credentials -> {
            BuildingAsyncTask task = new BuildingAsyncTask(this, ProjectFilePaths.ExportType.AAB);
            currentBuildingTask = task;
            task.enableAppBundleBuild();
            if (credentials != null) {
                if (credentials.isForSigningWithTestkey()) {
                    task.setSignWithTestkey(true);
                } else {
                    task.configureResultJarSigning(
                            SketchwarePaths.getKeystoreFilePath(),
                            credentials.getKeyStorePassword().toCharArray(),
                            credentials.getKeyAlias(),
                            credentials.getKeyPassword().toCharArray(),
                            credentials.getSigningAlgorithm()
                    );
                }
            }
            task.execute();
        });
        credentialsDialog.show();
    }

    /**
     * Initialize Export to Android Studio views
     */
    private void initializeExportSrcViews() {
        export_source_loading_anim.setVisibility(View.GONE);
        export_source_output_stage.setVisibility(View.GONE);
        export_source_button.setOnClickListener(v -> {
            export_source_button.setVisibility(View.GONE);
            export_source_output_stage.setVisibility(View.GONE);
            export_source_loading_anim.setVisibility(View.VISIBLE);
            export_source_loading_anim.playAnimation();
            BackgroundTasks.callIo(TaskHost.of(this), "ExportProjectActivity", this::exportSrc,
                    this::initializeAfterExportedSourceViews, error -> {
                        Log.e("ExportProjectActivity", "Failed to export source", error);
                        SketchwareUtil.showAnErrorOccurredDialog(this, Log.getStackTraceString(error));
                        export_source_output_stage.setVisibility(View.GONE);
                        if (export_source_loading_anim.isAnimating()) {
                            export_source_loading_anim.cancelAnimation();
                        }
                        export_source_loading_anim.setVisibility(View.GONE);
                        export_source_button.setVisibility(View.VISIBLE);
                    });
        });
        export_source_send_button.setOnClickListener(v -> shareExportedSourceCode());
    }

    /**
     * Initialize APK Export views
     */
    private void initializeSignApkViews() {
        sign_apk_loading_anim.setVisibility(View.GONE);
        sign_apk_output_stage.setVisibility(View.GONE);

        sign_apk_button.setOnClickListener(view -> {
            MaterialAlertDialogBuilder confirmationDialog = new MaterialAlertDialogBuilder(this);
            confirmationDialog.setTitle(Helper.getResString(R.string.export_title_important_note));
            confirmationDialog.setMessage(Helper.getResString(R.string.export_apk_sign_note));
            confirmationDialog.setIcon(R.drawable.ic_mtrl_info);

            confirmationDialog.setPositiveButton(Helper.getResString(R.string.export_btn_understood), (v, which) -> {
                showApkSigningDialog();
                v.dismiss();
            });
            confirmationDialog.show();
        });
    }

    private void showApkSigningDialog() {
        GetKeyStoreCredentialsDialog credentialsDialog = new GetKeyStoreCredentialsDialog(this,
                R.drawable.ic_mtrl_key,
                Helper.getResString(R.string.export_apk_sign_dialog_title),
                Helper.getResString(R.string.export_apk_sign_dialog_desc));
        credentialsDialog.setListener(credentials -> {
            sign_apk_button.setVisibility(View.GONE);
            sign_apk_output_stage.setVisibility(View.GONE);
            sign_apk_loading_anim.setVisibility(View.VISIBLE);
            sign_apk_loading_anim.playAnimation();

            BuildingAsyncTask task = new BuildingAsyncTask(this, ProjectFilePaths.ExportType.SIGN_APP);
            currentBuildingTask = task;
            if (credentials != null) {
                if (credentials.isForSigningWithTestkey()) {
                    task.setSignWithTestkey(true);
                } else {
                    task.configureResultJarSigning(
                            SketchwarePaths.getKeystoreFilePath(),
                            credentials.getKeyStorePassword().toCharArray(),
                            credentials.getKeyAlias(),
                            credentials.getKeyPassword().toCharArray(),
                            credentials.getSigningAlgorithm()
                    );
                }
            }
            task.execute();
        });
        credentialsDialog.show();
    }

    private void initializeOutputDirectories() {
        signed_apk_postfix = File.separator + "sketchware" + File.separator + "signed_apk";
        export_src_postfix = File.separator + "sketchware" + File.separator + "export_src";
        /* /sdcard/sketchware/signed_apk */
        String signed_apk_full_path = SketchwarePaths.getSketchwarePath() + File.separator + "signed_apk";
        export_src_full_path = SketchwarePaths.getSketchwarePath() + File.separator + "export_src";

        /* Check if they exist, if not, create them */
        file_utility.mkdirs(signed_apk_full_path);
        file_utility.mkdirs(export_src_full_path);
    }

    private void shareExportedSourceCode() {
        if (!export_src_filename.isEmpty()) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("plain/text");
            intent.putExtra(Intent.EXTRA_SUBJECT, Helper.getResString(R.string.myprojects_export_src_title_email_subject, export_src_filename));
            intent.putExtra(Intent.EXTRA_TEXT, Helper.getResString(R.string.myprojects_export_src_title_email_body, export_src_filename));
            String filePath = export_src_full_path + File.separator + export_src_filename;
            intent.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", new File(filePath)));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(Intent.createChooser(intent, Helper.getResString(R.string.myprojects_export_src_chooser_title_email)));
        }
    }

    /**
     * Set content of exported source views
     */
    private void initializeAfterExportedSourceViews(String exportedSrcFilename) {
        export_src_filename = exportedSrcFilename;
        export_source_loading_anim.cancelAnimation();
        export_source_loading_anim.setVisibility(View.GONE);
        export_source_output_stage.setVisibility(View.VISIBLE);
        export_source_output_path.setText(export_src_postfix + File.separator + export_src_filename);
    }

    private static class BuildingAsyncTask implements DialogInterface.OnCancelListener, BuildProgressReceiver {
        private final WeakReference<ExportProjectActivity> activity;
        private final TaskHost taskHost;
        private final ProjectFilePaths project_metadata;
        private final WeakReference<LottieAnimationView> loading_sign_apk;
        private final ProjectFilePaths.ExportType exportType;
        private final ExecutorService executorService = BackgroundTasks.createSingleThreadExecutor("ExportBuild");

        private ProjectBuilder builder;
        private volatile boolean canceled = false;
        private volatile boolean failed = false;
        private boolean buildingAppBundle = false;
        private String errorMessage = null;
        private String signingKeystorePath = null;
        private char[] signingKeystorePassword = null;
        private String signingAliasName = null;
        private char[] signingAliasPassword = null;
        private String signingAlgorithm = null;
        private boolean signWithTestkey = false;

        public BuildingAsyncTask(ExportProjectActivity exportProjectActivity, ProjectFilePaths.ExportType exportType) {
            this.exportType = exportType;
            activity = new WeakReference<>(exportProjectActivity);
            taskHost = TaskHost.of(exportProjectActivity);
            project_metadata = exportProjectActivity.project_metadata;
            loading_sign_apk = new WeakReference<>(exportProjectActivity.sign_apk_loading_anim);
            // Make a simple ProgressDialog show and set its OnCancelListener
            exportProjectActivity.showProgressDialogWithCancel((DialogInterface.OnCancelListener) this);
            // Allow user to use back button
            exportProjectActivity.progressDialog.setCancelable(false);
        }

        public void execute() {
            onPreExecute();
            executorService.execute(() -> {
                try {
                    doWork();
                } finally {
                    onPostExecute();
                }
            });
        }

        private void onPostExecute() {
            builder = null;
            executorService.shutdown();
            var act = activity.get();
            if (!isActivityAlive(act)) {
                return;
            }
            postToUi(act, () -> {
                if (failed) {
                    onError(errorMessage);
                } else if (canceled) {
                    onCancelled();
                } else {
                    onSuccess();
                }
                if (act.currentBuildingTask == this) {
                    act.currentBuildingTask = null;
                }
            });
        }

        private void publishProgress(String progress) {
            onProgressUpdate(progress);
        }

        /**
         * BaseAsyncTask's doWork() - runs in background thread
         */
        public void doWork() {
            if (canceled) {
                return;
            }

            var act = activity.get();
            if (act == null) return;
            var context = act.getApplicationContext();
            String sc_id = act.sc_id;

            try {
                publishProgress(Helper.getResString(R.string.build_progress_deleting_temp));
                FileUtil.deleteFile(project_metadata.projectMyscPath);

                publishProgress(Helper.getResString(R.string.design_run_title_ready_to_build));
                EncryptedFileUtil fileUtil = new EncryptedFileUtil();
                /* Check if /Internal storage/sketchware/signed_apk/ exists */
                if (!fileUtil.exists(SketchwarePaths.getSignedApkPath())) {
                    /* Doesn't exist yet, let's create it */
                    fileUtil.mkdirs(SketchwarePaths.getSignedApkPath());
                }
                ProjectFileManager hCVar = new ProjectFileManager(sc_id);
                ResourceManager kCVar = new ResourceManager(sc_id);
                ProjectDataStore eCVar = new ProjectDataStore(sc_id);
                LibraryManager iCVar = new LibraryManager(sc_id);
                hCVar.loadFromData();
                kCVar.loadFromData();
                eCVar.loadViewFromData();
                eCVar.loadLogicFromData();
                iCVar.loadFromData();
                if (canceled) {
                    return;
                }
                File outputFile = new File(getCorrectResultFilename(project_metadata.releaseApkPath));
                if (outputFile.exists()) {
                    if (!outputFile.delete()) {
                        throw new IllegalStateException("Couldn't delete file " + outputFile.getAbsolutePath());
                    }
                }
                project_metadata.createBuildDirectories(context);
                if (canceled) {
                    return;
                }
                project_metadata.extractAssetsToRes(context, SketchwarePaths.getResourceZipPath("600"));
                if (canceled) {
                    return;
                }
                if (MapValueHelper.get(ProjectListManager.getProjectById(sc_id), "custom_icon")) {
                    project_metadata.copyMipmapFolder(SketchwarePaths.getIconsPath() + File.separator + sc_id + File.separator + "mipmaps");
                    if (MapValueHelper.get(ProjectListManager.getProjectById(sc_id), "isIconAdaptive", false)) {
                        project_metadata.createLauncherIconXml("""
                                <?xml version="1.0" encoding="utf-8"?>
                                <adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android" >
                                <background android:drawable="@mipmap/ic_launcher_background"/>
                                <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
                                <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>
                                </adaptive-icon>""");
                    } else {
                        project_metadata.copyAppIcon(SketchwarePaths.getIconsPath() + File.separator + sc_id + File.separator + "icon.png");
                    }
                }
                project_metadata.deleteValuesV21Directory();
                kCVar.copyImagesToDir(project_metadata.resDirectoryPath + File.separator + "drawable-xhdpi");
                kCVar.copySoundsToDir(project_metadata.resDirectoryPath + File.separator + "raw");
                kCVar.copyFontsToDir(project_metadata.assetsPath + File.separator + "fonts");

                builder = new ProjectBuilder(this, context, project_metadata);
                builder.setBuildAppBundle(buildingAppBundle);

                project_metadata.initializeMetadata(iCVar, hCVar, eCVar, exportType);
                builder.buildBuiltInLibraryInformation();
                project_metadata.generateProjectFiles(hCVar, eCVar, iCVar, builder.getBuiltInLibraryManager());
                if (canceled) {
                    return;
                }

                /* Check AAPT/AAPT2 */
                publishProgress(Helper.getResString(R.string.build_progress_extracting_aapt2));
                builder.maybeExtractAapt2();
                if (canceled) {
                    return;
                }

                /* Check built-in libraries */
                publishProgress(Helper.getResString(R.string.build_progress_extracting_libraries));
                BuiltInLibraries.extractCompileAssets(this);
                if (canceled) {
                    return;
                }

                builder.buildBuiltInLibraryInformation();

                publishProgress(Helper.getResString(R.string.build_progress_aapt2_running));
                builder.compileResources();
                if (canceled) {
                    return;
                }

                KotlinCompilerBridge.compileKotlinCodeIfPossible(this, builder);
                if (canceled) {
                    return;
                }

                publishProgress(Helper.getResString(R.string.build_progress_java_compiling));
                builder.compileJavaCode();
                if (canceled) {
                    return;
                }

                /* Encrypt Strings in classes if enabled */
                StringfogHandler stringfogHandler = new StringfogHandler(project_metadata.sc_id);
                stringfogHandler.start(this, builder);
                if (canceled) {
                    return;
                }

                /* Obfuscate classes if enabled */
                ProguardHandler proguardHandler = new ProguardHandler(project_metadata.sc_id);
                proguardHandler.start(this, builder);
                if (canceled) {
                    return;
                }

                /* Create DEX file(s) */
                publishProgress(builder.getDxRunningText());
                builder.createDexFilesFromClasses();
                if (canceled) {
                    return;
                }

                /* Merge DEX file(s) with libraries' dexes */
                publishProgress(Helper.getResString(R.string.build_progress_merging_dex));
                builder.getDexFilesReady();
                if (canceled) {
                    return;
                }

                if (buildingAppBundle) {
                    AppBundleCompiler compiler = new AppBundleCompiler(builder);
                    publishProgress(Helper.getResString(R.string.build_progress_creating_module));
                    compiler.createModuleMainArchive();
                    publishProgress(Helper.getResString(R.string.build_progress_building_bundle));
                    compiler.buildBundle();

                    /* Sign the generated .aab file */
                    publishProgress(Helper.getResString(R.string.build_progress_signing_bundle));

                    String createdBundlePath = AppBundleCompiler.getDefaultAppBundleOutputFile(project_metadata).getAbsolutePath();
                    String signedAppBundleDirectoryPath = SketchwarePaths.getSignedAabPath();
                    FileUtil.makeDir(signedAppBundleDirectoryPath);
                    String outputPath = signedAppBundleDirectoryPath + File.separator +
                            Uri.fromFile(new File(createdBundlePath)).getLastPathSegment();

                    if (signWithTestkey) {
                        ZipSigner signer = new ZipSigner();
                        signer.setKeymode(ZipSigner.KEY_TESTKEY);
                        signer.signZip(createdBundlePath, outputPath);
                    } else if (isResultJarSigningEnabled()) {
                        Security.addProvider(new BouncyCastleProvider());
                        CustomKeySigner.signZip(
                                new ZipSigner(),
                                signingKeystorePath,
                                signingKeystorePassword,
                                signingAliasName,
                                signingAliasPassword,
                                signingAlgorithm,
                                createdBundlePath,
                                outputPath
                        );
                    } else {
                        FileUtil.copyFile(createdBundlePath, getCorrectResultFilename(outputPath));
                    }
                } else {
                    publishProgress(Helper.getResString(R.string.build_progress_building_apk));
                    builder.buildApk();
                    if (canceled) {
                        return;
                    }

                    publishProgress(Helper.getResString(R.string.build_progress_aligning_apk));
                    builder.runZipalign(builder.projectFilePaths.unsignedUnalignedApkPath, builder.projectFilePaths.unsignedAlignedApkPath);
                    if (canceled) {
                        return;
                    }

                    publishProgress(Helper.getResString(R.string.build_progress_signing_apk));
                    String outputLocation = getCorrectResultFilename(builder.projectFilePaths.releaseApkPath);
                    if (signWithTestkey) {
                        TestkeySignBridge.signWithTestkey(builder.projectFilePaths.unsignedAlignedApkPath, outputLocation);
                    } else if (isResultJarSigningEnabled()) {
                        Security.addProvider(new BouncyCastleProvider());
                        CustomKeySigner.signZip(
                                new ZipSigner(),
                                SketchwarePaths.getKeystoreFilePath(),
                                signingKeystorePassword,
                                signingAliasName,
                                signingAliasPassword,
                                signingAlgorithm,
                                builder.projectFilePaths.unsignedAlignedApkPath,
                                outputLocation
                        );
                    } else {
                        FileUtil.copyFile(builder.projectFilePaths.unsignedAlignedApkPath, outputLocation);
                    }
                }
            } catch (Throwable throwable) {
                failed = true;
                if (throwable instanceof LoadKeystoreException &&
                        "Incorrect password, or integrity check failed.".equals(throwable.getMessage())) {
                    errorMessage = "Either an incorrect password was entered, or your key store is corrupt.";
                } else {
                    Log.e("AppExporter", throwable.getMessage(), throwable);
                    errorMessage = Log.getStackTraceString(throwable);
                }

                cancelBuild();
            }
        }

        @Override
        public void onCancel(DialogInterface dialog) {
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            if (!act.progressDialog.isCancelable()) {
                act.progressDialog.setCancelable(true);
                act.showProgressDialogWithCancel((DialogInterface.OnCancelListener) this);
                publishProgress(Helper.getResString(R.string.build_progress_canceling));
                canceled = true;
            }
        }

        public void onCancelled() {
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            // Dismiss the ProgressDialog
            act.dismissProgressDialog();
            act.sign_apk_output_stage.setVisibility(View.GONE);
            LottieAnimationView loading_sign_apk = this.loading_sign_apk.get();
            if (loading_sign_apk != null) {
                if (loading_sign_apk.isAnimating()) {
                    loading_sign_apk.cancelAnimation();
                }
                loading_sign_apk.setVisibility(View.GONE);
            }
            act.sign_apk_button.setVisibility(View.VISIBLE);
        }

        public void onPreExecute() {
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        public void onProgressUpdate(String... strArr) {
            // Update the ProgressDialog's text
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            postToUi(act, () -> act.setProgressMessage(strArr[0]));
        }

        /**
         * BaseAsyncTask's onSuccess() - called on the UI thread after successful doWork()
         */
        public void onSuccess() {
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            // Dismiss the ProgressDialog
            act.dismissProgressDialog();

            if (new File(getCorrectResultFilename(project_metadata.releaseApkPath)).exists()) {
                act.showSignedApkOutput(getCorrectResultFilename(project_metadata.projectName + "_release.apk"));
            }

            String aabFilename = getCorrectResultFilename(project_metadata.projectName + ".aab");
            if (buildingAppBundle && new File(SketchwarePaths.getSignedAabPath(), aabFilename).exists()) {
                MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(act);
                dialog.setIcon(R.drawable.open_box_48);
                dialog.setTitle(Helper.getResString(R.string.export_aab_finished_title));
                dialog.setMessage(String.format(Helper.getResString(R.string.export_aab_finished_message), aabFilename));
                dialog.setPositiveButton(Helper.getResString(R.string.common_word_ok), null);
                dialog.show();
            }
        }

        /**
         * Called by BaseAsyncTask if doWork() returned a non-empty String,
         * ergo, an error occurred.
         */
        public void onError(String errorMessage) {
            var act = activity.get();
            if (!isActivityAlive(act)) return;
            act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            // Dismiss the ProgressDialog
            act.dismissProgressDialog();
            SketchwareUtil.showAnErrorOccurredDialog(act, errorMessage);
            act.sign_apk_output_stage.setVisibility(View.GONE);
            LottieAnimationView loading_sign_apk = this.loading_sign_apk.get();
            if (loading_sign_apk != null) {
                if (loading_sign_apk.isAnimating()) {
                    loading_sign_apk.cancelAnimation();
                }
                loading_sign_apk.setVisibility(View.GONE);
                act.sign_apk_button.setVisibility(View.VISIBLE);
            }
        }

        public void cancelBuild() {
            canceled = true;
        }

        private boolean isActivityAlive(ExportProjectActivity activity) {
            return activity != null && taskHost.isAlive();
        }

        private void postToUi(ExportProjectActivity activity, Runnable action) {
            if (activity == null || action == null) {
                return;
            }
            taskHost.postToUi(action);
        }

        public void enableAppBundleBuild() {
            buildingAppBundle = true;
        }

        /**
         * Configures parameters for JAR signing the result.
         * <p></p>
         * If {@link #signWithTestkey} is <code>true</code> though, the result will be signed
         * regardless of {@link #configureResultJarSigning(String, char[], String, char[], String)} and {@link #disableResultJarSigning()} calls.
         */
        public void configureResultJarSigning(String keystorePath, char[] keystorePassword, String aliasName, char[] aliasPassword, String signatureAlgorithm) {
            signingKeystorePath = keystorePath;
            signingKeystorePassword = keystorePassword;
            signingAliasName = aliasName;
            signingAliasPassword = aliasPassword;
            signingAlgorithm = signatureAlgorithm;
        }

        /**
         * Whether to sign the result with testkey or not.
         * Note that this value will always be prioritized over values set with {@link #configureResultJarSigning(String, char[], String, char[], String)}.
         */
        public void setSignWithTestkey(boolean signWithTestkey) {
            this.signWithTestkey = signWithTestkey;
        }

        /**
         * Disables JAR signing of the result. Equivalent to calling {@link #configureResultJarSigning(String, char[], String, char[], String)}
         * with <code>null</code> parameters.
         * <p></p>
         * If {@link #signWithTestkey} is <code>true</code> though, the result will be signed
         * regardless of {@link #configureResultJarSigning(String, char[], String, char[], String)} and {@link #disableResultJarSigning()} calls.
         */
        public void disableResultJarSigning() {
            signingKeystorePath = null;
            signingKeystorePassword = null;
            signingAliasName = null;
            signingAliasPassword = null;
            signingAlgorithm = null;
        }

        public boolean isResultJarSigningEnabled() {
            return signingKeystorePath != null && signingKeystorePassword != null &&
                    signingAliasName != null && signingAliasPassword != null && signingAlgorithm != null;
        }

        private String getCorrectResultFilename(String oldFormatFilename) {
            if (!isResultJarSigningEnabled() && !signWithTestkey) {
                if (buildingAppBundle) {
                    return oldFormatFilename.replace(".aab", ".unsigned.aab");
                } else {
                    return oldFormatFilename.replace("_release", "_release.unsigned");
                }
            } else {
                return oldFormatFilename;
            }
        }

        @Override
        public void onProgress(String progress, int step) {
            publishProgress(progress);
        }
    }
}
