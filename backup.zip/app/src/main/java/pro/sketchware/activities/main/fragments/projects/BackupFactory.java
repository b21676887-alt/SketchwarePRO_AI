package pro.sketchware.activities.main.fragments.projects;

import android.content.Context;

import pro.sketchware.util.FilePathUtil;
import android.util.Log;

import pro.sketchware.beans.BlockBean;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import pro.sketchware.core.project.ProjectListManager;
import pro.sketchware.util.MapValueHelper;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.util.library.LocalLibrariesUtil;
import pro.sketchware.core.codegen.ExtraBlockInfo;
import pro.sketchware.core.codegen.BlockLoader;
import pro.sketchware.activities.design.CustomBlocksManager;
import pro.sketchware.util.Helper;
import pro.sketchware.activities.settings.ConfigActivity;
import pro.sketchware.R;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.SketchwareUtil;

public class BackupFactory {
    public static final String EXTENSION = "swb";
    public static final String DEF_PATH = SketchwarePaths.BACKUPS_PATH + File.separator;

    // WARNING: These crypto constants are part of the original Sketchware project file format.
    // Do NOT change them — doing so will break reading/writing of all existing project files
    // and backups, as well as compatibility with other Sketchware variants.
    // The key == IV pattern is a known weakness but is required for format compatibility.
    private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final byte[] LEGACY_KEY = "sketchwaresecure".getBytes(java.nio.charset.StandardCharsets.UTF_8);

    private static final String[] resSubfolders = {
            "fonts", "icons", "images", "sounds"
    };

    final String sc_id;
    File outPath;
    boolean backupLocalLibs;
    boolean backupCustomBlocks;
    String error = "";
    boolean restoreSuccess = true;

    /**
     * @param sc_id For backing up, the target project's ID,
     *              for restoring, the new project ID
     */
    public BackupFactory(String sc_id) {
        this.sc_id = sc_id;
    }

    public static String getBackupDir() {
        return SketchwarePaths.resolveExternalStorageRelativePath(ConfigActivity.getBackupPath());
    }

    private static File getAllLocalLibsDir() {
        return FilePathUtil.getLocalLibsDir();
    }

    private static HashMap<String, Object> getProject(File file) {
        try {
            byte[] data;
            try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
                data = new byte[(int) raf.length()];
                raf.readFully(data);
            }
            try {
                Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(LEGACY_KEY, "AES"), new IvParameterSpec(LEGACY_KEY));
                byte[] decrypted = cipher.doFinal(data);
                return new Gson().fromJson(new String(decrypted, java.nio.charset.StandardCharsets.UTF_8).trim(), Helper.TYPE_MAP);
            } catch (Exception e) {
                // Decryption failed — project file is stored as plaintext
                return new Gson().fromJson(new String(data, java.nio.charset.StandardCharsets.UTF_8).trim(), Helper.TYPE_MAP);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean writeEncrypted(File file, String string) {
        String path = file.getAbsolutePath();

        try {
            byte[] data;
            if (pro.sketchware.activities.settings.ConfigActivity.isSettingEnabled(
                    pro.sketchware.activities.settings.ConfigActivity.SETTING_PROJECT_DATA_ENCRYPTION)) {
                Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
                cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(LEGACY_KEY, "AES"), new IvParameterSpec(LEGACY_KEY));
                data = cipher.doFinal((string.trim()).getBytes(java.nio.charset.StandardCharsets.UTF_8));
            } else {
                data = string.trim().getBytes(java.nio.charset.StandardCharsets.UTF_8);
            }
            try (RandomAccessFile raf = new RandomAccessFile(path, "rw")) {
                raf.setLength(0);
                raf.write(data);
            }

            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getNewScId() {
        File myscList = new File(SketchwarePaths.getProjectListBasePath());

        ArrayList<String> list = new ArrayList<>();
        FileUtil.listDir(myscList.getAbsolutePath(), list);
        //noinspection Java8ListSort
        Collections.sort(list, String.CASE_INSENSITIVE_ORDER);

        int id = 600;
        for (String path : list) {
            try {
                id = Math.max(id, Integer.parseInt(new File(path).getName()));
            } catch (NumberFormatException ignored) {
            }
        }
        return String.valueOf(id + 1);
    }

    /************************ UTILITIES ************************/

    public static boolean unzip(File zipFile, File destinationDir) {
        int DEFAULT_BUFFER = 2048;
        try (ZipFile zip = new ZipFile(zipFile)) {
            destinationDir.mkdirs();
            String canonicalDestDir = destinationDir.getCanonicalPath() + File.separator;
            Enumeration<? extends ZipEntry> zipFileEntries = zip.entries();
            while (zipFileEntries.hasMoreElements()) {
                ZipEntry entry = zipFileEntries.nextElement();
                String entryName = entry.getName();
                File destFile = new File(destinationDir, entryName);
                if (!destFile.getCanonicalPath().startsWith(canonicalDestDir)) {
                    throw new IOException("Zip entry outside target dir: " + entryName);
                }
                File destinationParent = destFile.getParentFile();
                if (destinationParent != null && !destinationParent.exists()) {
                    destinationParent.mkdirs();
                }
                if (!entry.isDirectory()) {
                    try (BufferedInputStream is = new BufferedInputStream(zip.getInputStream(entry))) {
                        int currentByte;
                        byte[] data = new byte[DEFAULT_BUFFER];
                        try (FileOutputStream fos = new FileOutputStream(destFile)) {
                            try (BufferedOutputStream dest = new BufferedOutputStream(fos, DEFAULT_BUFFER)) {
                                while ((currentByte = is.read(data, 0, DEFAULT_BUFFER)) != -1 /*EOF*/) {
                                    dest.write(data, 0, currentByte);
                                }
                                dest.flush();
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            return false;
        }
        return true;
    }

    public static void zipFolder(File srcFolder, File destZipFile) throws Exception {
        try (FileOutputStream fileWriter = new FileOutputStream(destZipFile)) {
            try (ZipOutputStream zip = new ZipOutputStream(fileWriter)) {
                addFolderToZip(srcFolder, srcFolder, zip);
                zip.flush();
            }
        }
    }

    private static void addFileToZip(File rootPath, File srcFile, ZipOutputStream zip) throws Exception {

        if (srcFile.isDirectory()) {
            addFolderToZip(rootPath, srcFile, zip);
        } else {
            byte[] buf = new byte[1024];
            int len;
            try (FileInputStream in = new FileInputStream(srcFile)) {
                String name = srcFile.getPath();
                name = name.replace(rootPath.getPath() + "/", "");
                zip.putNextEntry(new ZipEntry(name));
                while ((len = in.read(buf)) > 0) {
                    zip.write(buf, 0, len);
                }
            }
        }
    }

    private static void addFolderToZip(File rootPath, File srcFolder, ZipOutputStream zip) throws Exception {
        File[] srcFolderFiles = srcFolder.listFiles();
        if (srcFolderFiles != null) {
            for (File fileName : srcFolderFiles) {
                addFileToZip(rootPath, fileName, zip);
            }
        }
    }

    //6.3.0 fix1
    public static void createNomediaFileIn(File dir) {
        FileUtil.writeFile(new File(dir, ".nomedia").getAbsolutePath(), "");
    }

    //6.3.0 fix1
    public static void copySafe(File source, File destination) {
        if (!source.exists()) {
            destination.mkdirs();
            createNomediaFileIn(destination);
        } else {
            copy(source, destination);
        }
    }

    public static void copy(File source, File destination) {
        if (source.isDirectory()) {
            if (!destination.exists()) destination.mkdirs();

            String[] files = source.list();
            if (files != null) {

                for (String file : files) {
                    File srcFile = new File(source, file);
                    File destFile = new File(destination, file);

                    copy(srcFile, destFile);
                }
            }
        } else {
            //skip .nomedia files
            if (source.getName().equals(".nomedia")) return;

            try (InputStream in = new FileInputStream(source);
                 OutputStream out = new FileOutputStream(destination)) {
                byte[] buffer = new byte[1024];
                int length;
                while ((length = in.read(buffer)) > 0) {
                    out.write(buffer, 0, length);
                }
            } catch (IOException e) {
                Log.e("BackupFactory", e.getMessage(), e);
            }
        }
    }

    public static boolean zipContainsFile(String zipPath, String fileName) {
        try (ZipInputStream zp = new ZipInputStream(new FileInputStream(zipPath))) {
            ZipEntry en;
            while ((en = zp.getNextEntry()) != null) {
                String name = en.getName();
                if (name.equals(fileName) || name.startsWith(fileName + File.separator)) {
                    return true;
                }
            }
        } catch (Exception e) {
            Log.e("BackupFactory", "Failed to check zip contents", e);
        }
        return false;
    }

    /************************ BACKUP ************************/

    public void backup(Context context, String project_name) {
        String customFileName = ConfigActivity.getBackupFileName();

        String versionName = MapValueHelper.getString(ProjectListManager.getProjectById(sc_id), "sc_ver_name");
        String versionCode = MapValueHelper.getString(ProjectListManager.getProjectById(sc_id), "sc_ver_code");
        String pkgName = MapValueHelper.getString(ProjectListManager.getProjectById(sc_id), "my_sc_pkg_name");
        String projectNameOnly = project_name.replace("_d", "").replace(File.separator, "");
        String finalFileName;

        try {
            finalFileName = customFileName
                    .replace("$projectName", projectNameOnly)
                    .replace("$versionCode", versionCode)
                    .replace("$versionName", versionName)
                    .replace("$pkgName", pkgName)
                    .replace("$versionCode", versionCode)
                    .replace("$timeInMs", String.valueOf(Calendar.getInstance(Locale.ENGLISH).getTimeInMillis()));
            Matcher matcher = Pattern.compile("\\$time\\((.*?)\\)").matcher(customFileName);
            while (matcher.find()) {
                finalFileName = finalFileName.replaceFirst(
                        Pattern.quote(Objects.requireNonNull(matcher.group(0))),
                        Matcher.quoteReplacement(getFormattedDateFrom(matcher.group(1))));
            }
        } catch (Exception ignored) {
            SketchwareUtil.toastError(Helper.getResString(R.string.error_parse_backup_filename));
            // Example name: InternalDemo v1.0 (com.jbk.internal.demo, 1) 2021-12-31T125827
            finalFileName = projectNameOnly + " v" + versionName + " (" + pkgName + ", " + versionCode + ") " + getFormattedDateFrom("yyyy-M-dd'T'HHmmss");
        }
        createBackupsFolder();

        // Init temporary backup folder
        File outFolder = new File(getBackupDir(),
                project_name + "_temp");

        // Init output zip file
        File outZip = new File(getBackupDir() + File.separator + projectNameOnly, finalFileName +
                //Adds all the _d if exists. Otherwise its possible that there'll be an infinite loop
                (project_name.contains("_d") ? project_name.replace(projectNameOnly, "") : "") + "." + EXTENSION);

        // Create a duplicate if already exists (impossible now :3)
        if (outZip.exists()) {
            backup(context, project_name + "_d");
            return;
        }
        //delete temp dir if exist
        if (outFolder.exists()) {
            FileUtil.deleteFile(outFolder.getAbsolutePath());
        }

        // Create necessary folders
        FileUtil.makeDir(outFolder.getAbsolutePath());
        FileUtil.makeDir(new File(getBackupDir() + File.separator + projectNameOnly).getAbsolutePath());

        // Copy data
        File dataF = new File(outFolder, "data");
        FileUtil.makeDir(dataF.getAbsolutePath());
        //6.3.0 fix1
        copySafe(getDataDir(), dataF);

        // Copy res
        File resF = new File(outFolder, "resources");
        FileUtil.makeDir(resF.getAbsolutePath());

        for (String subfolder : resSubfolders) {
            File resSubf = new File(resF, subfolder);
            FileUtil.makeDir(resSubf.getAbsolutePath());

            //6.3.0 fix1
            copySafe(getResDir(subfolder), resSubf);

            // Write an empty file inside each folder (except icons)
            if (!subfolder.equals("icons")) {
                //6.3.0 fix1
                createNomediaFileIn(resSubf);
                //FileUtil.writeFile(new File(resSubf, ".nomedia").getAbsolutePath(), "");
            }
        }

        // Copy project
        File projectF = new File(outFolder, "project");
        copy(getProjectPath(), projectF);

        // Find local libs used and include them in the backup
        if (backupLocalLibs) {
            File localLibs = getLocalLibsPath();

            if (localLibs.exists()) {
                try {
                    JSONArray ja = new JSONArray(FileUtil.readFile(localLibs.getAbsolutePath()));

                    File libsF = new File(outFolder, "local_libs");
                    libsF.mkdirs();

                    for (int i = 0; i < ja.length(); i++) {
                        JSONObject jo = ja.getJSONObject(i);
                        String libName = jo.optString("name", "");
                        if (libName.isEmpty()) continue;

                        File libDir = new File(getAllLocalLibsDir(), libName);
                        if (!libDir.exists()) {
                            libDir = new File(FilePathUtil.getLocalLibsFallbackDir(), libName);
                        }
                        if (libDir.isDirectory()) {
                            copy(libDir, new File(libsF, libName));
                        }
                    }

                } catch (Exception e) {
                    Log.e("BackupFactory", "Failed to backup local libraries", e);
                }
            }
        }

        // Find custom blocks used and include them in the backup
        if (backupCustomBlocks) {
            CustomBlocksManager cbm = new CustomBlocksManager(context, sc_id);

            Set<ExtraBlockInfo> blocks = new HashSet<>();
            Set<String> block_names = new HashSet<>();
            for (BlockBean bean : cbm.getUsedBlocks()) {
                if (!block_names.contains(bean.opCode)) {
                    block_names.add(bean.opCode);
                    if (cbm.contains(bean.opCode)) {
                        blocks.add(cbm.getExtraBlockInfo(bean.opCode));
                    } else {
                        var block = BlockLoader.getBlockInfo(bean.opCode);
                        blocks.add(block);
                    }
                }
            }

            String json = new Gson().toJson(blocks);

            File customBlocksF = new File(dataF, "custom_blocks");
            FileUtil.writeFile(customBlocksF.getAbsolutePath(), json);
        }

        // Zip final folder
        try {
            zipFolder(outFolder, outZip);
        } catch (Exception e) {
            error = Log.getStackTraceString(e);
            outPath = null;
            FileUtil.deleteFile(outFolder.getAbsolutePath());
            if (outZip.exists()) {
                FileUtil.deleteFile(outZip.getAbsolutePath());
            }
            return;
        }

        // Delete the temporary folder
        FileUtil.deleteFile(outFolder.getAbsolutePath());

        // Put outZip to global variable
        outPath = outZip;
    }

    private String getFormattedDateFrom(String format) {
        return new SimpleDateFormat(format, Locale.ENGLISH).format(Calendar.getInstance().getTime());
    }

    public File getOutFile() {
        return outPath;
    }

    public void setBackupLocalLibs(boolean backupLocalLibs) {
        this.backupLocalLibs = backupLocalLibs;
    }

    public void setBackupCustomBlocks(boolean backupCustomBlocks) {
        this.backupCustomBlocks = backupCustomBlocks;
    }

    /************************ RESTORE ************************/

    public void restore(File swbPath) {
        String name = swbPath.getName();
        if (name.contains(".")) {
            name = name.substring(0, name.lastIndexOf("."));
        }

        restore(swbPath, name);
    }

    private void restore(File swbPath, String name) {

        createBackupsFolder();

        // Init temporary restore folder for unzipping
        File outFolder = new File(getBackupDir(),
                name);

        // Create a duplicate if already exists
        if (outFolder.exists()) {
            restore(swbPath, name + "_d");
            return;
        }

        // Unzip
        if (!unzip(swbPath, outFolder)) {
            error = "couldn't unzip the backup";
            restoreSuccess = false;
            FileUtil.deleteFile(outFolder.getAbsolutePath());
            return;
        }

        // Init files
        File project = new File(outFolder, "project");
        File data = new File(outFolder, "data");
        File res = new File(outFolder, "resources");

        HashMap<String, Object> map = getProject(project);

        if (map == null) {
            error = "couldn't read the project file";
            restoreSuccess = false;
            FileUtil.deleteFile(outFolder.getAbsolutePath());
            return;
        }

        // Put new sc_id
        map.put("sc_id", sc_id);

        // Write new file
        if (!writeEncrypted(project, new Gson().toJson(map))) {
            error = "couldn't write to the project file";
            restoreSuccess = false;
            FileUtil.deleteFile(outFolder.getAbsolutePath());
            return;
        }

        // Copy data
        copy(data, getDataDir());

        // Copy res
        for (String subfolder : resSubfolders) {
            File subf = new File(res, subfolder);

            copySafe(subf, getResDir(subfolder));
        }

        // Create parent folder
        getProjectPath().getParentFile().mkdirs();

        // Copy project
        copy(project, getProjectPath());

        // Copy local libs if they do not exist
        if (backupLocalLibs) {
            File local_libs = new File(outFolder, "local_libs");

            if (local_libs.exists()) {
                File[] local_libs_content = local_libs.listFiles();
                if (local_libs_content != null) {

                    for (File local_lib : local_libs_content) {

                        File primaryPath = new File(getAllLocalLibsDir(), local_lib.getName());
                        File fallbackPath = new File(FilePathUtil.getLocalLibsFallbackDir(), local_lib.getName());

                        if (!primaryPath.exists() && !fallbackPath.exists()) {
                            try {
                                primaryPath.mkdirs();
                                copy(local_lib, primaryPath);
                            } catch (Exception e) {
                                // Primary path blocked by FUSE, clean up empty dir
                                // and use app-specific fallback
                                FileUtil.deleteFile(primaryPath.getAbsolutePath());
                                fallbackPath.mkdirs();
                                copy(local_lib, fallbackPath);
                            }
                        }
                    }
                }
            }
        }

        // Rebuild local_library paths to use current device's storage layout
        rebuildLocalLibraryPaths();

        // Delete temp folder
        FileUtil.deleteFile(outFolder.getAbsolutePath());

        restoreSuccess = true;
    }

    private void rebuildLocalLibraryPaths() {
        ArrayList<HashMap<String, Object>> libs = LocalLibrariesUtil.getLocalLibraries(sc_id);
        if (libs.isEmpty()) return;

        ArrayList<HashMap<String, Object>> rebuilt = new ArrayList<>();
        for (HashMap<String, Object> lib : libs) {
            String name = MapValueHelper.getString(lib, "name");
            if (name == null || name.isEmpty()) continue;
            String dependency = MapValueHelper.getString(lib, "dependency");
            rebuilt.add(LocalLibrariesUtil.createLibraryMap(name, dependency.isEmpty() ? null : dependency));
        }
        LocalLibrariesUtil.rewriteLocalLibFile(sc_id, new Gson().toJson(rebuilt));
    }

    public String getError() {
        return error;
    }

    public boolean isRestoreSuccess() {
        return restoreSuccess;
    }

    /************************ SW METHODS ************************/

    private void createBackupsFolder() {
        // Create the backups folder if it doesn't exist
        String backupsPath = getBackupDir();

        FileUtil.makeDir(backupsPath);
    }

    private File getDataDir() {
        return new File(SketchwarePaths.getDataPath(sc_id));
    }

    private File getResDir(String subfolder) {
        String resourcePath = switch (subfolder) {
            case "fonts" -> SketchwarePaths.getFontsResourcePath();
            case "icons" -> SketchwarePaths.getIconsPath();
            case "images" -> SketchwarePaths.getImagesPath();
            case "sounds" -> SketchwarePaths.getSoundsPath();
            default -> SketchwarePaths.getAbsolutePathOf(SketchwarePaths.RESOURCES_PATH + File.separator + subfolder);
        };
        return new File(resourcePath, sc_id);
    }

    private File getProjectPath() {
        return new File(SketchwarePaths.getProjectListPath(sc_id), "project");
    }

    private File getLocalLibsPath() {
        return new File(SketchwarePaths.getProjectLocalLibraryPath(sc_id));
    }
}
