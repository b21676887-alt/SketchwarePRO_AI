package pro.sketchware.core.project;

import static android.text.TextUtils.isEmpty;

import pro.sketchware.beans.AdTestDeviceBean;
import pro.sketchware.beans.ProjectLibraryBean;

import java.util.ArrayList;
import java.util.HashMap;

public class BuildConfig {

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#CALL_PHONE
     */
    public static final int PERMISSION_CALL_PHONE = 1;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#INTERNET
     */
    public static final int PERMISSION_INTERNET = 2;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#VIBRATE
     */
    public static final int PERMISSION_VIBRATE = 4;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#ACCESS_NETWORK_STATE
     */
    public static final int PERMISSION_ACCESS_NETWORK_STATE = 8;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#CAMERA
     */
    public static final int PERMISSION_CAMERA = 16;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#READ_EXTERNAL_STORAGE
     */
    public static final int PERMISSION_READ_EXTERNAL_STORAGE = 32;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#WRITE_EXTERNAL_STORAGE
     */
    public static final int PERMISSION_WRITE_EXTERNAL_STORAGE = 64;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#RECORD_AUDIO
     */
    public static final int PERMISSION_RECORD_AUDIO = 128;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#BLUETOOTH
     */
    public static final int PERMISSION_BLUETOOTH = 256;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#BLUETOOTH_ADMIN
     */
    public static final int PERMISSION_BLUETOOTH_ADMIN = 512;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#ACCESS_FINE_LOCATION
     */
    public static final int PERMISSION_ACCESS_FINE_LOCATION = 1024;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#BLUETOOTH_CONNECT
     */
    public static final int PERMISSION_BLUETOOTH_CONNECT = 2048;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#READ_MEDIA_IMAGES
     */
    public static final int PERMISSION_READ_MEDIA_IMAGES = 4096;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#READ_MEDIA_VIDEO
     */
    public static final int PERMISSION_READ_MEDIA_VIDEO = 8192;

    /**
     * A permission type for {@link BuildConfig#addPermission(String, int)}, {@link BuildConfig#addPermission(int)} and {@link ActivityConfig#addPermission(int)}.
     *
     * @see android.Manifest.permission#READ_MEDIA_AUDIO
     */
    public static final int PERMISSION_READ_MEDIA_AUDIO = 16384;

    /**
     * Project's package name,
     * e.g. com.jbk.internal.demo.
     */
    public String packageName = "";

    /**
     * Application's name of project,
     * e.g. Sketchware Pro Remod Remod Demo.
     */
    public String projectName;

    /**
     * Project version code,
     * e.g. 1
     */
    public String versionCode;

    /**
     * Project's version name,
     * e.g. 1.0
     */
    public String versionName;

    /**
     * If we're building a debug APK, meaning that e.g. test ads should be used.
     */
    public boolean isDebugBuild = false;

    /**
     * If the built-in library AppCompat (contains the Jetpack AppCompat artefacts and
     * Material Design Components) is enabled.
     */
    public boolean isAppCompatEnabled = false;

    /**
     * If the built-in library Firebase is enabled.
     */
    public boolean isFirebaseEnabled = false;

    /**
     * If there's at least 1 Firebase Auth Component in the project.
     */
    public boolean isFirebaseAuthUsed = false;

    /**
     * If there's at least 1 Firebase Database Component in the project.
     */
    public boolean isFirebaseDatabaseUsed = false;

    /**
     * If there's at least 1 Firebase Storage Component in the project.
     */
    public boolean isFirebaseStorageUsed = false;

    /**
     * If the built-in library AdMob is enabled.
     */
    public boolean isAdMobEnabled = false;

    /**
     * If the built-in library Google Map is enabled.
     */
    public boolean isMapUsed = false;

    /**
     * If at least 1 block in the project uses the built-in library Glide.
     */
    public boolean isGlideUsed = false;

    /**
     * If at least 1 block in the project uses the built-in library Gson.
     */
    public boolean isGsonUsed = false;

    /**
     * If at least 1 component in the project uses the built-in library OkHttp3.
     */
    public boolean isHttp3Used = false;

    /**
     * If at least 1 TextToSpeech Component ({@link pro.sketchware.beans.ComponentBean#COMPONENT_TYPE_TEXT_TO_SPEECH})
     * is used in the project.
     */
    public boolean isTextToSpeechUsed = false;

    /**
     * If at least 1 SpeechToText Component ({@link pro.sketchware.beans.ComponentBean#COMPONENT_TYPE_SPEECH_TO_TEXT})
     * is used in the project.
     */
    public boolean isSpeechToTextUsed = false;

    /**
     * If at least 1 Notification Component ({@link pro.sketchware.beans.ComponentBean#COMPONENT_TYPE_NOTIFICATION})
     * is used in the project.
     */
    public boolean isNotificationUsed = false;

    /**
     * Permissions of the whole project, stored as bitfield.
     */
    public int permissions = 0;

    /**
     * Configured ad unit ID for banner ads. Set to demo ad unit provided by Google by default.
     */
    public String bannerAdUnitId = "ca-app-pub-3940256099942544/6300978111";

    /**
     * Configured ad unit ID for interstitial ads. Set to demo ad unit provided by Google by default.
     */
    public String interstitialAdUnitId = "ca-app-pub-3940256099942544/1033173712";

    /**
     * Configured ad unit ID for RewardedAd ads. Set to demo ad unit provided by Google by default.
     */
    public String rewardAdUnitId = "ca-app-pub-3940256099942544/5224354917";

    public String appId = "";

    public String sc_id = "";

    /**
     * Device IDs registered as Test Devices for the current project.
     */
    public ArrayList<String> testDeviceIds = new ArrayList<>();
    public boolean isFileProviderUsed = false;

    /**
     * (Most likely) the Google Maps API key associated with the project.
     */
    public String mapApiKey = "";

    /**
     * Map containing permissions of Activities. Activity name = {@link String},
     * Permissions container = {@link ActivityConfig}.
     */
    public HashMap<String, ActivityConfig> activityPermissions = new HashMap<>();
    public ConstVarComponent constVarComponent = new ConstVarComponent();

    public boolean hasPermissions() {
        return permissions == 0;
    }

    public void reset() {
    }

    /**
     * @return True if the permission was registered on the project.
     */
    public boolean hasPermission(int permission) {
        return (permissions & permission) == permission;
    }

    /**
     * Registers a permission for the entire project.
     */
    public void addPermission(int permission) {
        permissions = permission | permissions;
    }

    /**
     * (Most likely) sets the Google Maps API key.
     */
    public void setupGoogleMap(ProjectLibraryBean googleMapsLibrary) {
        String data;
        if (googleMapsLibrary != null && (data = googleMapsLibrary.data) != null) {
            mapApiKey = data;
        }
    }

    /**
     * Registers a permission for an Activity.
     */
    public void addPermission(String activityName, int permission) {
        if (!activityPermissions.containsKey(activityName)) {
            activityPermissions.put(activityName, new ActivityConfig());
        }
        activityPermissions.get(activityName).addPermission(permission);
        addPermission(permission);
    }

    /** Returns the permissions object for the Activity. */
    public ActivityConfig getActivityPermissions(String activityName) {
        return getOrCreateActivityPermissions(activityName);
    }

    public ActivityConfig getOrCreateActivityPermissions(String activityName) {
        if (!activityPermissions.containsKey(activityName)) {
            activityPermissions.put(activityName, new ActivityConfig());
        }
        return activityPermissions.get(activityName);
    }

    public void setupAdmob(ProjectLibraryBean projectLibraryBean) {
        ArrayList<AdTestDeviceBean> testDevices;
        if (!(projectLibraryBean == null || (testDevices = projectLibraryBean.testDevices) == null || testDevices.size() <= 0)) {
            for (AdTestDeviceBean adTestDeviceBean : projectLibraryBean.testDevices) {
                testDeviceIds.add(adTestDeviceBean.deviceId);
            }
        }
        String reserved1;
        if (!(projectLibraryBean == null || (reserved1 = projectLibraryBean.reserved1) == null || reserved1.isEmpty())) {
            bannerAdUnitId = reserved1.substring(reserved1.lastIndexOf(" : ") + 3);
        }
        String reserved2;
        if (projectLibraryBean != null && (reserved2 = projectLibraryBean.reserved2) != null && !reserved2.isEmpty()) {
            interstitialAdUnitId = reserved2.substring(reserved2.lastIndexOf(" : ") + 3);
        }
        String reserved3;
        if (projectLibraryBean != null && (reserved3 = projectLibraryBean.reserved3) != null && !reserved3.isEmpty()) {
            rewardAdUnitId = reserved3.substring(reserved3.lastIndexOf(" : ") + 3);
        }
        String app_id;
        if (!(projectLibraryBean == null || (app_id = projectLibraryBean.appId) == null || isEmpty(app_id))) {
            appId = app_id;
        }
    }

    public static class ActivityConfig {
        /**
         * True if Activity contains a Drawer.
         */
        public boolean hasDrawer = false;

        /**
         * True if Activity uses Firebase Auth.
         */
        public boolean usesFirebaseAuth = false;

        /**
         * The permissions bitfield.
         */
        public int permissions = 0;

        public void addPermission(int permission) {
            permissions = permission | permissions;
        }

        public boolean hasPermission(int permission) {
            return (permissions & permission) == permission;
        }

        /**
         * @return (Most likely) true if the Activity associated with this {@link ActivityConfig} object
         * will request any runtime permissions
         */
        public boolean needsRuntimePermissions() {
            return hasPermission(PERMISSION_CALL_PHONE)
                    || hasPermission(PERMISSION_READ_EXTERNAL_STORAGE) || hasPermission(PERMISSION_WRITE_EXTERNAL_STORAGE)
                    || hasPermission(PERMISSION_CAMERA)
                    || hasPermission(PERMISSION_RECORD_AUDIO)
                    || hasPermission(PERMISSION_ACCESS_FINE_LOCATION)
                    || hasPermission(PERMISSION_BLUETOOTH_CONNECT)
                    || hasPermission(PERMISSION_READ_MEDIA_IMAGES)
                    || hasPermission(PERMISSION_READ_MEDIA_VIDEO)
                    || hasPermission(PERMISSION_READ_MEDIA_AUDIO);
        }
    }
}
