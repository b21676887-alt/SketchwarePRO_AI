package pro.sketchware.core.codegen;
import pro.sketchware.core.project.BuildConfig;
import pro.sketchware.core.project.ClassInfo;
import pro.sketchware.core.project.ProjectDataStore;

import pro.sketchware.beans.BlockBean;
import pro.sketchware.beans.ComponentBean;
import pro.sketchware.beans.EventBean;
import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.beans.ViewBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pro.sketchware.core.project.ProjectSettings;
import pro.sketchware.core.codegen.ComponentExtraCode;
import pro.sketchware.core.build.ViewBindingBuilder;
import pro.sketchware.core.codegen.BlockInterpreter;
import pro.sketchware.core.codegen.CodeContext;
import pro.sketchware.core.codegen.EventRegistry;

public class EventCodeGenerator {

    private final ProjectFileBean projectFileBean;
    private final BuildConfig buildConfig;
    private final ArrayList<Event> viewEvents = new ArrayList<>();
    private final ArrayList<Event> componentEvents = new ArrayList<>();
    private final ArrayList<ActivityEvent> activityEvents = new ArrayList<>();
    private final ArrayList<Event> authEvents = new ArrayList<>();
    private final ArrayList<Event> drawerViewEvents = new ArrayList<>();
    private final ArrayList<ComponentCallback> callbackEvents = new ArrayList<>();
    private final ArrayList<String> imports = new ArrayList<>();
    private final HashMap<String, String> activityLifecycleEvents = new HashMap<>();
    private final Boolean isViewBindingEnabled;
    private final CodeContext codeContext;
    public String eventLogic = "";
    public String eventListenerCode = "";

    public EventCodeGenerator(BuildConfig logicHolder, ProjectFileBean projectFileBean, ProjectDataStore projectDataStore, CodeContext codeContext) {
        buildConfig = logicHolder;
        this.projectFileBean = projectFileBean;
        this.codeContext = codeContext;

        ProjectSettings projectSettings = new ProjectSettings(logicHolder.sc_id);
        isViewBindingEnabled = projectSettings.getValue(ProjectSettings.SETTING_ENABLE_VIEWBINDING, "false").equals("true");

        ArrayList<ViewBean> views = new ArrayList<>(projectDataStore.getViews(projectFileBean.getXmlName()));
        if (projectFileBean.hasActivityOption(ProjectFileBean.OPTION_ACTIVITY_FAB)) {
            ViewBean fab = projectDataStore.getFabView(projectFileBean.getXmlName());
            views.add(fab);
        }
        for (ViewBean view : views) {
            viewEvents.add(new Event(this, isViewBindingEnabled ? "binding." + ViewBindingBuilder.generateParameterFromId(view.id) : view.id, view.getClassInfo(), isViewBindingEnabled));
        }

        ArrayList<ComponentBean> components = projectDataStore.getComponents(projectFileBean.getJavaName());
        for (ComponentBean componentBean : components) {
            int type = componentBean.type;
            if (type == ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH || type == ComponentBean.COMPONENT_TYPE_INTERSTITIAL_AD) {
                authEvents.add(new Event(this, componentBean.componentId, componentBean.getClassInfo(), isViewBindingEnabled));
            } else {
                componentEvents.add(new Event(this, componentBean.componentId, componentBean.getClassInfo(), isViewBindingEnabled));
            }
        }

        if (projectFileBean.hasActivityOption(ProjectFileBean.OPTION_ACTIVITY_DRAWER)) {
            ArrayList<ViewBean> drawerViews = projectDataStore.getViews(projectFileBean.getDrawerXmlName());
            for (ViewBean view : drawerViews) {
                drawerViewEvents.add(new Event(this, isViewBindingEnabled ? "binding.drawer." + ViewBindingBuilder.generateParameterFromId(view.id) : "_drawer_" + view.id, view.getClassInfo(), isViewBindingEnabled));
            }
        }

        processEvents(projectDataStore.getEvents(projectFileBean.getJavaName()), projectDataStore.getBlockMap(projectFileBean.getJavaName()));
    }

    public String getOnActivityResultSwitchCases() {
        StringBuilder sb = new StringBuilder(4096);
        for (ComponentCallback value : callbackEvents) {
            String code = value.getCode();
            if (sb.length() > 0 && !code.isEmpty()) {
                sb.append(ActivityCodeGenerator.EOL);
                sb.append(ActivityCodeGenerator.EOL);
            }
            sb.append(code);
        }
        return sb.toString();
    }

    private void addCallbackEvents(int targetType, String targetId, String eventName, String eventLogic) {
        boolean hasOnSuccessLogic = eventName.equals("onPictureTaken") || eventName.equals("onAccountPicker") || eventName.equals("onFilesPicked");
        boolean hasOnCancelledLogic = eventName.equals("onPictureTakenCancel") || eventName.equals("onFilesPickedCancel") || eventName.equals("onAccountPickerCancelled");

        boolean alreadyRegistered = false;
        for (ComponentCallback next : callbackEvents) {
            if (next.componentName.equals(targetId)) {
                if (hasOnSuccessLogic) {
                    next.setOnSuccessLogic(eventLogic);
                    return;
                } else if (hasOnCancelledLogic) {
                    next.setOnCancelledLogic(eventLogic);
                    return;
                } else {
                    alreadyRegistered = true;
                }
            }
        }
        if (!alreadyRegistered) {
            ComponentCallback event = new ComponentCallback(targetType, targetId, codeContext);
            if (hasOnSuccessLogic) {
                event.setOnSuccessLogic(eventLogic);
            } else if (hasOnCancelledLogic) {
                event.setOnCancelledLogic(eventLogic);
            }
            callbackEvents.add(event);
        }
    }

    private void addActivityEvent(String eventName, String eventLogic) {
        ActivityEvent target = null;

        for (ActivityEvent next : activityEvents) {
            if (next.name.equals(eventName)) {
                target = next;
                break;
            }
        }

        if (target == null) {
            target = new ActivityEvent(eventName);
            activityEvents.add(target);
        }
        target.setLogic(eventLogic);
    }

    public void addLifecycleEvent(String eventName, String viewType, String viewId) {
        String code = ComponentCodeGenerator.getDefaultActivityLifecycleCode(eventName, viewType, viewId);
        if (!code.isEmpty()) {
            activityLifecycleEvents.merge(eventName, code, (existing, newCode) -> existing + "\r\n" + newCode);
        }
    }

    private void processEvents(ArrayList<EventBean> events, HashMap<String, ArrayList<BlockBean>> logicBlocks) {
        for (EventBean eventBean : events) {
            ArrayList<BlockBean> eventLogicBlocks = logicBlocks.get(eventBean.targetId + "_" + eventBean.eventName);
            String eventLogic = (eventLogicBlocks == null || eventLogicBlocks.isEmpty()) ? "" :
                    new BlockInterpreter(projectFileBean.getActivityName(), buildConfig, eventLogicBlocks, isViewBindingEnabled, projectFileBean.getXmlName()).interpretBlocks();

            switch (eventBean.eventType) {
                case EventBean.EVENT_TYPE_VIEW:
                    addViewListeners(eventBean.targetId, eventBean.eventName, eventLogic);
                    break;

                case EventBean.EVENT_TYPE_COMPONENT:
                    switch (eventBean.targetType) {
                        case ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH:
                        case ComponentBean.COMPONENT_TYPE_INTERSTITIAL_AD:
                            addCallbackEvents(eventBean.targetId, eventBean.eventName, eventLogic);
                            break;

                        case ComponentBean.COMPONENT_TYPE_CAMERA:
                        case ComponentBean.COMPONENT_TYPE_FILE_PICKER:
                        case ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH_GOOGLE_LOGIN:
                            addCallbackEvents(eventBean.targetType, eventBean.targetId, eventBean.eventName, eventLogic);
                            break;

                        default:
                            addViewImports(eventBean.targetId, eventBean.eventName, eventLogic);
                    }
                    break;

                case EventBean.EVENT_TYPE_ACTIVITY:
                    addActivityEvent(eventBean.eventName, eventLogic);
                    break;

                case EventBean.EVENT_TYPE_DRAWER_VIEW:
                    addDrawerEvents(eventBean.targetId, eventBean.eventName, eventLogic);
                    break;

                default:
            }
        }
    }

    public String generateActivityLifecycleEventCode() {
        StringBuilder sb = new StringBuilder(4096);
        for (Map.Entry<String, String> event : activityLifecycleEvents.entrySet()) {
            String name = event.getKey();
            String logic = event.getValue();

            ActivityEvent matchedEvent = null;
            for (ActivityEvent next : activityEvents) {
                if (next.name.equals(name)) {
                    matchedEvent = next;
                    break;
                }
            }
            if (matchedEvent == null) {
                ActivityEvent a = new ActivityEvent(name);
                a.setLogic(logic);
                activityEvents.add(a);
            } else {
                matchedEvent.logic = logic + "\r\n" + matchedEvent.logic;
            }
        }

        for (ActivityEvent value : activityEvents) {
            String code = value.getCode();
            if (sb.length() > 0 && !code.isEmpty()) {
                sb.append(ActivityCodeGenerator.EOL);
                sb.append(ActivityCodeGenerator.EOL);
            }
            sb.append(code);
        }
        return sb.toString();
    }

    private void addViewImports(String targetId, String eventName, String eventLogic) {
        for (Event next : componentEvents) {
            if (next.id.equals(targetId)) {
                next.addEvent(targetId, eventName, eventLogic);
                return;
            }
        }
    }

    public String generateComponentEvents() {
        StringBuilder sb = new StringBuilder(4096);
        ComponentExtraCode componentExtraCode = new ComponentExtraCode(this, sb);
        for (Event next : componentEvents) {
            componentExtraCode.appendListenerCode(next.generateEvent());
        }
        return sb.toString();
    }

    private void addDrawerEvents(String targetId, String eventName, String eventLogic) {
        for (Event next : drawerViewEvents) {
            if (next.id.equals(isViewBindingEnabled ? "binding.drawer." + ViewBindingBuilder.generateParameterFromId(targetId) : "_drawer_" + targetId)) {
                next.addEvent(targetId, eventName, eventLogic);
                return;
            }
        }
    }

    public String generateDrawerEvents() {
        StringBuilder sb = new StringBuilder(4096);
        for (Event drawerViewEvent : drawerViewEvents) {
            String eventCodes = drawerViewEvent.generateEvent();
            if (sb.length() > 0 && !eventCodes.isEmpty()) {
                sb.append(ActivityCodeGenerator.EOL);
                sb.append(ActivityCodeGenerator.EOL);
            }
            sb.append(eventCodes);
        }
        return sb.toString();
    }

    private void addCallbackEvents(String targetId, String eventName, String eventLogic) {
        for (Event next : authEvents) {
            if (next.id.equals(targetId)) {
                next.addEvent(targetId, eventName, eventLogic);
                return;
            }
        }
    }

    /**
     * @return {@link EventCodeGenerator#imports}
     */
    public ArrayList<String> getImports() {
        return imports;
    }

    private void addViewListeners(String targetId, String eventName, String eventLogic) {
        for (Event next : viewEvents) {
            if (next.id.equals(isViewBindingEnabled ? "binding." + ViewBindingBuilder.generateParameterFromId(targetId) : targetId)) {
                next.addEvent(targetId, eventName, eventLogic);
                return;
            }
        }
    }

    public String generateAuthEvents() {
        StringBuilder sb = new StringBuilder(4096);
        for (Event authEvent : authEvents) {
            String event = authEvent.generateEvent();
            if (sb.length() > 0 && !event.isEmpty()) {
                sb.append(ActivityCodeGenerator.EOL);
                sb.append(ActivityCodeGenerator.EOL);
            }
            sb.append(event);
        }
        return sb.toString();
    }

    public String generateViewEvents() {
        StringBuilder sb = new StringBuilder(4096);
        for (Event value : viewEvents) {
            String event = value.generateEvent();
            if (sb.length() > 0 && !event.isEmpty()) {
                sb.append(ActivityCodeGenerator.EOL);
                sb.append(ActivityCodeGenerator.EOL);
            }
            sb.append(event);
        }
        return sb.toString();
    }

    private static class ActivityEvent {

        private final String name;
        private String logic = "";
        private String targetId = "";

        private ActivityEvent(String name) {
            this.name = name;
        }

        private String getCode() {
            return ComponentCodeGenerator.getEventCode(targetId, name, logic);
        }

        private void setLogic(String logic) {
            this.logic = logic;
        }

        private void setTargetId(String targetId) {
            this.targetId = targetId;
        }
    }

    private static class ComponentCallback {

        private final int componentId;
        private final String componentName;
        private final CodeContext codeContext;
        private String onSuccessCode = "";
        private String onCancelledCode = "";

        private ComponentCallback(int componentId, String componentName, CodeContext codeContext) {
            this.componentId = componentId;
            this.componentName = componentName;
            this.codeContext = codeContext;
        }

        private void setOnCancelledLogic(String onCancelledLogic) {
            onCancelledCode = onCancelledLogic;
        }

        private void setOnSuccessLogic(String onSuccessLogic) {
            onSuccessCode = onSuccessLogic;
        }

        private String getCode() {
            return ComponentCodeGenerator.getOnActivityResultCode(codeContext, componentId, componentName, onSuccessCode, onCancelledCode);
        }
    }

    private static class Event {
        private final EventCodeGenerator eventCodeGenerator;
        private final String id;
        private final ArrayList<ComponentEvents> listeners = new ArrayList<>();

        private Event(EventCodeGenerator eventCodeGenerator, String id, ClassInfo classInfo, boolean isViewBindingEnabled) {
            this.eventCodeGenerator = eventCodeGenerator;
            this.id = id;

            String[] listeners = EventRegistry.getListenersForClass(classInfo);
            if (listeners.length > 0) {
                for (String listener : listeners) {
                    /* Found functionally same instructions in vanilla Sketchware, keep it this way */
                    if (!this.listeners.contains(listener)) {
                        this.listeners.add(new ComponentEvents(listener));
                    }
                }

                switch (classInfo.getClassName()) {
                    case "FirebaseDB":
                    case "FirebaseStorage":
                    case "FirebaseAuth":
                    case "Gyroscope":
                    case "FragmentAdapter":
                    case "WebView":
                    case "MapView":
                    case "InterstitialAd":
                    case "RequestNetwork":
                    case "BluetoothConnect":
                    case "SQLiteDatabase":
                        for (ComponentEvents value : this.listeners) {
                            value.isInitialized = true;
                        }
                        break;

                    default:
                }
            }
        }

        private String generateEvent() {
            StringBuilder sb = new StringBuilder(4096);
            for (ComponentEvents value : listeners) {
                String event = value.generateEvent(id);
                if (sb.length() > 0 && !event.isEmpty()) {
                    sb.append(ActivityCodeGenerator.EOL);
                    sb.append(ActivityCodeGenerator.EOL);
                }
                sb.append(event);
            }

            return sb.toString();
        }

        private void addEvent(String targetId, String eventName, String eventLogic) {
            for (ComponentEvents listener : listeners) {
                for (ActivityEvent activityEvent : listener.activityEvents) {
                    if (activityEvent.name.equals(eventName)) {
                        activityEvent.setLogic(eventLogic);
                        activityEvent.setTargetId(targetId);
                        listener.isInitialized = true;
                    }
                }

                if (listener.isInitialized) {
                    eventCodeGenerator.imports.addAll(ComponentTypeMapper.getListenerImports(listener.listenerName));
                }
            }
        }

    }

    private static class ComponentEvents {

        private final String listenerName;
        private final ArrayList<ActivityEvent> activityEvents;
        /**
         * Probably "if associated to a Component"/"got its code added"
         */
        private boolean isInitialized = false;

        private ComponentEvents(String listenerName) {
            this.listenerName = listenerName;
            activityEvents = new ArrayList<>();
            for (String eventName : EventRegistry.getEventsForListener(listenerName)) {
                activityEvents.add(new ActivityEvent(eventName));
            }
        }

        private String generateEvent(String componentName) {
            if (!isInitialized) {
                return "";
            }
            StringBuilder eventsCode = new StringBuilder(4096);
            for (ActivityEvent activityEvent : activityEvents) {
                String code = activityEvent.getCode();
                if (eventsCode.length() > 0 && !code.isEmpty()) {
                    eventsCode.append(ActivityCodeGenerator.EOL);
                    eventsCode.append(ActivityCodeGenerator.EOL);
                }
                eventsCode.append(code);
            }
            return ComponentCodeGenerator.getListenerCode(listenerName, componentName, eventsCode.toString());
        }
    }
}
