package pro.sketchware.core.codegen;

import java.util.ArrayList;

import pro.sketchware.core.project.ClassInfo;
import pro.sketchware.util.Helper;
import pro.sketchware.R;

public class ManageEvent {

    /**
     * Used in {@link pro.sketchware.core.codegen.EventRegistry#getEventsForClass(ClassInfo)} to retrieve extra Events of Components.
     */
    public static void addExtraEvents(ClassInfo classInfo, ArrayList<String> events) {
        if (classInfo.matchesType("RatingBar")) {
            events.add("onRatingChanged");
        }
        if (classInfo.matchesType("TimePicker")) {
            events.add("onTimeChanged");
        }
        if (classInfo.matchesType("DatePicker")) {
            events.add("onDateChanged");
        }
        if (classInfo.matchesType("VideoView")) {
            events.add("onPrepared");
            events.add("onError");
            events.add("onCompletion");
        }
        if (classInfo.matchesType("SearchView")) {
            events.add("onQueryTextSubmit");
            events.add("onQueryTextChanged");
        }
        if (classInfo.matchesType("ListView")) {
            events.add("onScrollChanged");
            events.add("onScrolled");
        }
        if (classInfo.matchesType("RecyclerView")) {
            events.add("onBindCustomView");
            events.add("onRecyclerScrollChanged");
            events.add("onRecyclerScrolled");
        }
        if (classInfo.matchesType("GridView")) {
            events.add("onItemClicked");
            events.add("onItemLongClicked");
            events.add("onBindCustomView");
        }
        if (classInfo.matchesType("Spinner")) {
            events.add("onBindCustomView");
        }
        if (classInfo.matchesType("ViewPager")) {
            events.add("onBindCustomView");
            events.add("onPageScrolled");
            events.add("onPageSelected");
            events.add("onPageChanged");
        }
        if (classInfo.matchesType("TabLayout")) {
            events.add("onTabSelected");
            events.add("onTabUnselected");
            events.add("onTabReselected");
        }
        if (classInfo.matchesType("BottomNavigationView")) {
            events.add("onNavigationItemSelected");
        }
        if (classInfo.matchesType("PatternLockView")) {
            events.add("onPatternLockStarted");
            events.add("onPatternLockProgress");
            events.add("onPatternLockComplete");
            events.add("onPatternLockCleared");
        }
        if (classInfo.matchesType("WaveSideBar")) {
            events.add("onLetterSelected");
        }
        EventsHandler.addEvents(classInfo, events);
    }

    /**
     * Used in {@link pro.sketchware.core.codegen.EventRegistry#getListenersForClass(ClassInfo)}
     * to get extra listeners for Components and Widgets.
     */
    public static void addExtraListeners(ClassInfo classInfo, ArrayList<String> listeners) {
        if (classInfo.matchesType("RatingBar")) {
            listeners.add("OnRatingBarChangeListener");
        }
        if (classInfo.matchesType("TimePicker")) {
            listeners.add("OnTimeChangeListener");
        }
        if (classInfo.matchesType("DatePicker")) {
            listeners.add("OnDateChangeListener");
        }
        if (classInfo.matchesType("VideoView")) {
            listeners.add("OnPreparedListener");
            listeners.add("OnErrorListener");
            listeners.add("OnCompletionListener");
        }
        if (classInfo.matchesType("SearchView")) {
            listeners.add("OnQueryTextListener");
        }
        if (classInfo.matchesType("TimePickerDialog")) {
            listeners.add("OnTimeSetListener");
        }
        if (classInfo.matchesType("DatePickerDialog")) {
            listeners.add("OnDateSetListener");
        }
        if (classInfo.matchesType("FragmentAdapter")) {
            listeners.add("FragmentStatePagerAdapter");
        }
        if (classInfo.matchesType("RewardedVideoAd")) {
            listeners.add("rewardedAdLoadCallback");
            listeners.add("fullScreenContentCallback");
            listeners.add("onUserEarnedRewardListener");
        }
        if (classInfo.matchesType("ListView")) {
            listeners.add("OnScrollListener");
        }
        if (classInfo.matchesType("RecyclerView")) {
            listeners.add("OnRecyclerScrollListener");
        }
        if (classInfo.matchesType("GridView")) {
            listeners.add("OnGridItemClickListener");
            listeners.add("OnGridItemLongClickListener");
        }
        if (classInfo.matchesType("ViewPager")) {
            listeners.add("OnPageChangeListener");
            listeners.add("OnAdapterChangeListener");
        }
        if (classInfo.matchesType("TabLayout")) {
            listeners.add("OnTabSelectedListener");
        }
        if (classInfo.matchesType("BottomNavigationView")) {
            listeners.add("OnNavigationItemSelected");
        }
        if (classInfo.matchesType("PatternLockView")) {
            listeners.add("PatternLockViewListener");
        }
        if (classInfo.matchesType("WaveSideBar")) {
            listeners.add("OnLetterSelectedListener");
        }
        if (classInfo.matchesType("FirebaseAuth")) {
            listeners.add("authUpdateEmailComplete");
            listeners.add("authUpdatePasswordComplete");
            listeners.add("authEmailVerificationSent");
            listeners.add("authDeleteUserComplete");
            listeners.add("authsignInWithPhoneAuth");
            listeners.add("authUpdateProfileComplete");
            listeners.add("googleSignInListener");
        }
        if (classInfo.matchesType("FirebasePhoneAuth")) {
            listeners.add("OnVerificationStateChangedListener");
        }
        if (classInfo.matchesType("FirebaseCloudMessage")) {
            listeners.add("OnCompleteListenerFCM");
        }
        EventsHandler.addListeners(classInfo, listeners);
    }

    /**
     * Used in {@link pro.sketchware.core.codegen.EventRegistry#getEventsForListener(String)} to get extra listeners' Events.
     */
    public static void addEventsForListener(String eventName, ArrayList<String> list) {
        switch (eventName) {
            case "rewardedAdLoadCallback":
                list.add("onRewardAdLoaded");
                list.add("onRewardAdFailedToLoad");
                return;

            case "onUserEarnedRewardListener":
                list.add("onUserEarnedReward");
                return;

            case "OnCompletionListener":
                list.add("onCompletion");
                return;

            case "OnDateSetListener":
                list.add("onDateSet");
                return;

            case "OnQueryTextListener":
                list.add("onQueryTextSubmit");
                list.add("onQueryTextChanged");
                return;

            case "OnVerificationStateChangedListener":
                list.add("onVerificationCompleted");
                list.add("onVerificationFailed");
                list.add("onCodeSent");
                return;

            case "OnScrollListener":
                list.add("onScrollChanged");
                list.add("onScrolled");
                return;

            case "authsignInWithPhoneAuth":
                list.add("signInWithPhoneAuthComplete");
                return;

            case "FragmentStatePagerAdapter":
                list.add("onTabAdded");
                list.add("onFragmentAdded");
                return;

            case "OnTimeSetListener":
                list.add("onTimeSet");
                return;

            case "OnFailureListener":
                list.add("onFailureLink");
                return;

            case "authUpdatePasswordComplete":
                list.add("onUpdatePasswordComplete");
                return;

            case "OnSuccessListener":
                list.add("onSuccessLink");
                return;

            case "OnGridItemClickListener":
                list.add("onItemClicked");
                return;

            case "OnRecyclerScrollListener":
                list.add("onRecyclerScrollChanged");
                list.add("onRecyclerScrolled");
                return;

            case "OnTimeChangeListener":
                list.add("onTimeChanged");
                return;

            case "authDeleteUserComplete":
                list.add("onDeleteUserComplete");
                return;

            case "authUpdateProfileComplete":
                list.add("onUpdateProfileComplete");
                return;

            case "OnPageChangeListener":
                list.add("onPageScrolled");
                list.add("onPageSelected");
                list.add("onPageChanged");
                return;

            case "OnErrorListener":
                list.add("onError");
                return;

            case "authEmailVerificationSent":
                list.add("onEmailVerificationSent");
                return;

            case "authUpdateEmailComplete":
                list.add("onUpdateEmailComplete");
                return;

            case "OnPreparedListener":
                list.add("onPrepared");
                return;

            case "OnNavigationItemSelected":
                list.add("onNavigationItemSelected");
                return;

            case "OnLetterSelectedListener":
                list.add("onLetterSelected");
                return;

            case "OnRatingBarChangeListener":
                list.add("onRatingChanged");
                return;

            case "OnTabSelectedListener":
                list.add("onTabSelected");
                list.add("onTabUnselected");
                list.add("onTabReselected");
                return;

            case "OnDateChangeListener":
                list.add("onDateChanged");
                return;

            case "OnCompleteListenerFCM":
                list.add("onCompleteRegister");
                return;

            case "PatternLockViewListener":
                list.add("onPatternLockStarted");
                list.add("onPatternLockProgress");
                list.add("onPatternLockComplete");
                list.add("onPatternLockCleared");
                return;

            case "OnGridItemLongClickListener":
                list.add("onItemLongClicked");
                return;

            case "googleSignInListener":
                list.add("onGoogleSignIn");
                return;

            default:
                EventsHandler.addEventsToListener(eventName, list);
        }
    }

    public static int getDrawableForEvent(String eventName) {
        return switch (eventName) {
            case "onUpdateProfileComplete" -> R.drawable.ic_mtrl_user_edit;
            case "onEmailVerificationSent" -> R.drawable.ic_mtrl_sms_check;
            case "onDateChanged", "onDateSet" -> R.drawable.ic_mtrl_date_changed;
            case "onFailureLink" -> R.drawable.ic_mtrl_link_fail;
            case "onDeleteUserComplete" -> R.drawable.ic_mtrl_user_remove;
            case "onCompletion" -> R.drawable.ic_mtrl_vid_completed;
            case "onQueryTextChanged", "onQueryTextSubmit" -> R.drawable.ic_mtrl_search;
            case "onUpdateEmailComplete" -> R.drawable.ic_mtrl_email_sent;
            case "onRestoreInstanceState" -> R.drawable.ic_mtrl_warning;
            case "onError" -> R.drawable.ic_mtrl_vid_error;
            case "onVerificationCompleted" -> R.drawable.ic_mtrl_verified_user;
            case "onSaveInstanceState", "onCreateOptionsMenu", "onCreateContextMenu",
                 "onContextItemSelected", "onOptionsItemSelected" ->
                    R.drawable.bg_event_type_activity;
            case "onSuccessLink" -> R.drawable.ic_mtrl_link_check;
            case "onPatternLockCleared", "onPatternLockProgress", "onPatternLockStarted",
                 "onPatternLockComplete" -> R.drawable.ic_mtrl_pattern;
            case "onAccountPickerCancelled" -> R.drawable.ic_mtrl_user_delete;
            case "onVerificationFailed" -> R.drawable.ic_mtrl_gpp_bad;
            case "onGoogleSignIn" -> R.drawable.event_google_signin;
            case "onAccountPicker" -> R.drawable.ic_mtrl_group;
            case "onFragmentAdded" -> R.drawable.ic_mtrl_viewpager;
            case "onTimeSet", "onTimeChanged" -> R.drawable.ic_mtrl_timer;
            case "signInWithPhoneAuthComplete", "onCodeSent" -> R.drawable.ic_mtrl_email_sent;
            case "onRatingChanged" -> R.drawable.ic_mtrl_star;
            case "onLetterSelected" -> R.drawable.ic_mtrl_abc_click;
            case "onScrollChanged", "onPageChanged", "onPageScrolled", "onRecyclerScrolled",
                 "onRecyclerScrollChanged", "onNavigationItemSelected", "onScrolled",
                 "onTabUnselected", "onPageSelected", "onTabSelected", "onTabReselected" ->
                    R.drawable.ic_mtrl_touch_long;
            case "onPrepared" -> R.drawable.ic_mtrl_vid_prepared;
            case "onTabAdded" -> R.drawable.ic_mtrl_post_added;
            case "onCompleteRegister" -> R.drawable.ic_mtrl_user_register_complete;
            case "onUpdatePasswordComplete" -> R.drawable.ic_mtrl_password;
            case "onUserEarnedReward" -> R.drawable.ic_mtrl_payment;
            default -> EventsHandler.getIcon(eventName);
        };
    }

    /**
     * @return Descriptions for Events added by Agus
     */
    public static String getEventDescription(String eventName) {
        return switch (eventName) {
            case "onScrolled", "onRecyclerScrolled" -> "onScroll";
            case "onFailureLink" -> "onFailure";
            case "onSaveInstanceState" -> Helper.getResString(R.string.event_onsaveinstancestate);
            case "onCreateOptionsMenu" -> Helper.getResString(R.string.event_oncreateoptionsmenu);
            case "onVerificationCompleted" -> "onVerificationCompleted";
            case "onRecyclerScrollChanged", "onScrollChanged" -> "onScrollStateChanged";
            case "onCreateContextMenu" -> Helper.getResString(R.string.event_oncreatecontextmenu);
            case "onRestoreInstanceState" -> Helper.getResString(R.string.event_onrestoreinstancestate);
            case "onContextItemSelected" -> Helper.getResString(R.string.event_oncontextitemselected);
            case "onSuccessLink" -> "onSuccess";
            case "onAccountPickerCancelled" -> "onAccountCancelled";
            case "onFragmentAdded" -> Helper.getResString(R.string.event_onfragmentadded);
            case "onPageChanged" -> "onPageScrollStateChanged";
            case "onOptionsItemSelected" -> Helper.getResString(R.string.event_onoptionsitemselected);
            case "onBannerAdClicked" -> "onAdClicked";
            case "onBannerAdLoaded" -> "onAdLoaded";
            case "onTabAdded" -> Helper.getResString(R.string.event_ontabadded);
            case "onCompleteRegister" -> "onComplete";
            case "onBannerAdFailedToLoad", "onInterstitialAdFailedToLoad" -> "onAdFailedToLoad";
            case "onBannerAdClosed" -> "onAdClosed";
            case "onRewardAdLoaded" -> "onRewardedAdLoaded";
            case "onRewardAdFailedToLoad" -> "onRewardedAdFailedToLoad";
            case "onUpdateProfileComplete", "onEmailVerificationSent", "onDateChanged",
                 "onDeleteUserComplete", "onNavigationItemSelected", "onDateSet", "onCompletion",
                 "onPatternLockCleared", "onQueryTextChanged", "onUpdateEmailComplete", "onError",
                 "onPageScrolled", "onVerificationFailed", "onGoogleSignIn", "onAccountPicker",
                 "onTimeSet", "signInWithPhoneAuthComplete", "onRatingChanged",
                 "onPatternLockProgress", "onTabSelected", "onTabReselected", "onLetterSelected",
                 "onTabUnselected", "onPageSelected", "onPrepared", "onQueryTextSubmit",
                 "onCodeSent", "onTimeChanged", "onUpdatePasswordComplete",
                 "onAdDismissedFullScreenContent", "onAdFailedToShowFullScreenContent",
                 "onAdShowedFullScreenContent", "onUserEarnedReward", "onSQLiteError" -> eventName;
            default -> EventsHandler.getDesc(eventName);
        };
    }

    public static String getExtraEventCode(String targetId, String eventName, String eventLogic) {
        String code;
        String resetInterstitialAd = targetId.isEmpty() ? "" : targetId + " = null;\r\n";
        String setAdFullScreenContentCallback = targetId.isEmpty() ? "\r\n" : targetId + " = _param1;\r\n" +
                targetId + ".setFullScreenContentCallback(_" + targetId + "_full_screen_content_callback);\r\n" +
                eventLogic + "\r\n";
        return switch (eventName) {
            case "onUpdateProfileComplete", "onEmailVerificationSent", "onDeleteUserComplete",
                 "onUpdateEmailComplete", "onUpdatePasswordComplete" -> "@Override\r\n" +
                    "public void onComplete(Task<Void> _param1) {\r\n" +
                    "final boolean _success = _param1.isSuccessful();\r\n" +
                    "final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : \"\";\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onScrolled" -> "@Override\r\n" +
                    "public void onScroll(AbsListView abs, int _firstVisibleItem, int _visibleItemCount, int _totalItemCount) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onDateChanged" -> "@Override\r\n" +
                    "public void onDateChanged(DatePicker _datePicker, int _year, int _month, int _day) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onFailureLink" -> "@Override\r\n" +
                    "public void onFailure(Exception _e) {\r\n" +
                    "final String _errorMessage = _e.getMessage();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onNavigationItemSelected" -> "@Override\r\n" +
                    "public boolean onNavigationItemSelected(MenuItem item) {\r\n" +
                    "final int _itemId = item.getItemId();\r\n" +
                    eventLogic + "\r\n" +
                    "return true;\r\n" +
                    "}";
            case "onDateSet" -> "@Override\r\n" +
                    "public void onDateSet(DatePicker _datePicker, int _year, int _month, int _day) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onCompletion" -> "@Override\r\n" +
                    "public void onCompletion(MediaPlayer _mediaPlayer) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onSaveInstanceState" -> "@Override\r\n" +
                    "protected void onSaveInstanceState(Bundle outState) {\r\n" +
                    eventLogic + "\r\n" +
                    "super.onSaveInstanceState(outState);\r\n" +
                    "}";
            case "onCreateOptionsMenu" -> "@Override\r\n" +
                    "public boolean onCreateOptionsMenu(Menu menu) {\r\n" +
                    eventLogic + "\r\n" +
                    "return super.onCreateOptionsMenu(menu);\r\n" +
                    "}";
            case "onQueryTextChanged" -> "@Override\r\n" +
                    "public boolean onQueryTextChange(String _charSeq) {\r\n" +
                    eventLogic + "\r\n" +
                    "return true;\r\n" +
                    "}";
            case "onError" -> "@Override\r\n" +
                    "public boolean onError(MediaPlayer _mediaPlayer, int _what, int _extra) {\r\n" +
                    eventLogic + "\r\n" +
                    "return true;\r\n" +
                    "}";
            case "onVerificationCompleted" -> "@Override\r\n" +
                    "public void onVerificationCompleted(PhoneAuthCredential _credential) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onRecyclerScrollChanged" -> "@Override\r\n" +
                    "public void onScrollStateChanged(RecyclerView recyclerView, int _scrollState) {\r\n" +
                    "super.onScrollStateChanged(recyclerView, _scrollState);\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onCreateContextMenu" -> "@Override\r\n" +
                    "public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo) {\r\n" +
                    eventLogic + "\r\n" +
                    "super.onCreateContextMenu(menu, view, menuInfo);\r\n" +
                    "}";
            case "onRestoreInstanceState" -> "@Override\r\n" +
                    "protected void onRestoreInstanceState(Bundle savedInstanceState) {\r\n" +
                    eventLogic + "\r\n" +
                    "super.onRestoreInstanceState(savedInstanceState);\r\n" +
                    "}";
            case "onContextItemSelected" -> "@Override\r\n" +
                    "public boolean onContextItemSelected(MenuItem item) {\r\n" +
                    eventLogic + "\r\n" +
                    "return super.onContextItemSelected(item);\r\n" +
                    "}";
            case "onRecyclerScrolled" -> "@Override\r\n" +
                    "public void onScrolled(RecyclerView recyclerView, int _offsetX, int _offsetY) {\r\n" +
                    "super.onScrolled(recyclerView, _offsetX, _offsetY);\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPatternLockCleared" -> "@Override\r\n" +
                    "public void onCleared() {\r\n" +
                    eventLogic + "\n" +
                    "}";
            case "onPageScrolled" -> "@Override\r\n" +
                    "public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onVerificationFailed" -> "@Override\r\n" +
                    "public void onVerificationFailed(FirebaseException e) {\r\n" +
                    "final String _exception = e.getMessage();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onGoogleSignIn" -> "@Override\r\n" +
                    "public void onComplete(Task<AuthResult> task) {\r\n" +
                    "final boolean _success = task.isSuccessful();\r\n" +
                    "final String _errorMessage = task.getException() != null ? task.getException().getMessage() : \"\";\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onFragmentAdded" -> buildMethodWithFallbackReturn("""
                    @Override
                    public Fragment getItem(int _position) {
                        %s
                    }
                    """, eventLogic, "new Fragment()");
            case "onTimeSet" -> "@Override\r\n" +
                    "public void onTimeSet(TimePicker _timePicker, int _hour, int _minute) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPageChanged" -> "@Override\r\n" +
                    "public void onPageScrollStateChanged(int _scrollState) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "signInWithPhoneAuthComplete" -> "@Override\r\n" +
                    "public void onComplete(Task<AuthResult> task) {\r\n" +
                    "final boolean _success = task.isSuccessful();\r\n" +
                    "final String _errorMessage = task.getException() != null ? task.getException().getMessage() : \"\";\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onRatingChanged" -> "@Override\r\n" +
                    "public void onRatingChanged(RatingBar _ratingBar, float _value, boolean _fromUser) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPatternLockProgress" -> "@Override\r\n" +
                    "public void onProgress(List<PatternLockView.Dot> _pattern) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onOptionsItemSelected" -> "@Override\r\n" +
                    "public boolean onOptionsItemSelected(MenuItem item) {\r\n" +
                    "final int _id = item.getItemId();\r\n" +
                    "final String _title = (String) item.getTitle();\r\n" +
                    eventLogic + "\r\n" +
                    "return super.onOptionsItemSelected(item);\r\n" +
                    "}";
            case "onPatternLockStarted" -> "@Override\r\n" +
                    "public void onStarted() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPatternLockComplete" -> "@Override\r\n" +
                    "public void onComplete(List<PatternLockView.Dot> _pattern) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onTabSelected" -> "@Override\r\n" +
                    "public void onTabSelected(TabLayout.Tab tab) {\r\n" +
                    "final int _position = tab.getPosition();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onTabReselected" -> "@Override\r\n" +
                    "public void onTabReselected(TabLayout.Tab tab) {\r\n" +
                    "final int _position = tab.getPosition();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onLetterSelected" -> "@Override\r\n" +
                    "public void onLetterSelected(String _index) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onTabUnselected" -> "@Override\r\n" +
                    "public void onTabUnselected(TabLayout.Tab tab) {\r\n" +
                    "final int _position = tab.getPosition();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPageSelected" -> "@Override\r\n" +
                    "public void onPageSelected(int _position) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onPrepared" -> "@Override\r\n" +
                    "public void onPrepared(MediaPlayer _mediaPlayer) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onQueryTextSubmit" -> "@Override\r\n" +
                    "public boolean onQueryTextSubmit(String _charSeq) {\r\n" +
                    eventLogic + "\r\n" +
                    "return true;\r\n" +
                    "}";
            case "onTabAdded" -> buildMethodWithFallbackReturn("""
                    @Override
                    public CharSequence getPageTitle(int _position) {
                        %s
                    }
                    """, eventLogic, "\"\"");
            case "onCompleteRegister" -> "@Override\r\n" +
                    "public void onComplete(Task<String> task) {\r\n" +
                    "final boolean _success = task.isSuccessful();\r\n" +
                    "final String _token = task.isSuccessful() ? task.getResult() : \"\";\r\n" +
                    "final String _errorMessage = task.getException() != null ? task.getException().getMessage() : \"\";\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onCodeSent" -> "@Override\r\n" +
                    "public void onCodeSent(String _verificationId, PhoneAuthProvider.ForceResendingToken _token) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onTimeChanged" -> "@Override\r\n" +
                    "public void onTimeChanged(TimePicker _timePicker, int _hour, int _minute) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onScrollChanged" -> "@Override\r\n" +
                    "public void onScrollStateChanged(AbsListView abs, int _scrollState) {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onInterstitialAdLoaded" -> {
                code = setAdFullScreenContentCallback;
                yield "@Override\r\n" +
                        "public void onAdLoaded(InterstitialAd _param1) {\r\n" +
                        code +
                        "}";
            }
            case "onBannerAdFailedToLoad", "onInterstitialAdFailedToLoad",
                 "onRewardAdFailedToLoad" -> "@Override\r\n" +
                    "public void onAdFailedToLoad(LoadAdError _param1) {\r\n" +
                    "final int _errorCode = _param1.getCode();\r\n" +
                    "final String _errorMessage = _param1.getMessage();\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onAdDismissedFullScreenContent" -> {
                code = resetInterstitialAd;
                yield "@Override\r\n" +
                        "public void onAdDismissedFullScreenContent() {\r\n" +
                        code +
                        eventLogic + "\r\n" +
                        "}";
            }
            case "onAdFailedToShowFullScreenContent" -> {
                code = resetInterstitialAd;
                yield "@Override\r\n" +
                        "public void onAdFailedToShowFullScreenContent(AdError _adError) {\r\n" +
                        code +
                        "final int _errorCode = _adError.getCode();\r\n" +
                        "final String _errorMessage = _adError.getMessage();\r\n" +
                        eventLogic + "\r\n" +
                        "}";
            }
            case "onAdShowedFullScreenContent" -> "@Override\r\n" +
                    "public void onAdShowedFullScreenContent() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onBannerAdClicked" -> "@Override\r\n" +
                    "public void onAdClicked() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onBannerAdClosed" -> "@Override\r\n" +
                    "public void onAdClosed() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onBannerAdLoaded" -> "@Override\r\n" +
                    "public void onAdLoaded() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onBannerAdOpened" -> "@Override\r\n" +
                    "public void onAdOpened() {\r\n" +
                    eventLogic + "\r\n" +
                    "}";
            case "onRewardAdLoaded" -> {
                code = setAdFullScreenContentCallback;
                yield "@Override\r\n" +
                        "public void onAdLoaded(RewardedAd _param1) {\r\n" +
                        code +
                        "}";
            }
            case "onUserEarnedReward" -> eventLogic;
            case "onSQLiteError" -> eventLogic;
            default -> EventsHandler.getEventCode(targetId, eventName, eventLogic);
        };
    }

    /**
     * @return Code of extra listeners, used in {@link pro.sketchware.core.codegen.ComponentCodeGenerator#getListenerCode(String, String, String)}
     */
    public static String getExtraListenerCode(String listenerName, String targetId, String listenerLogic) {
        return switch (listenerName) {
            case "OnCompletionListener" ->
                    targetId + ".setOnCompletionListener(new MediaPlayer.OnCompletionListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnDateSetListener" ->
                    "public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {\r\n" +
                            "@Override\r\n" +
                            "public Dialog onCreateDialog(Bundle savedInstanceState) {\r\n" +
                            "final Calendar c = Calendar.getInstance();\r\n" +
                            "int year = c.get(Calendar.YEAR);\r\n" +
                            "int month = c.get(Calendar.MONTH);\r\n" +
                            "int day = c.get(Calendar.DAY_OF_MONTH);\r\n" +
                            "return new DatePickerDialog(getActivity(), this, year, month, day);\r\n" +
                            "}\r\n" +
                            listenerLogic + "\r\n" +
                            "}";
            case "OnQueryTextListener" ->
                    targetId + ".setOnQueryTextListener(new SearchView.OnQueryTextListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnVerificationStateChangedListener" ->
                    targetId + " = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "OnScrollListener" ->
                    targetId + ".setOnScrollListener(new AbsListView.OnScrollListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "authsignInWithPhoneAuth" ->
                    targetId + "_phoneAuthListener = new OnCompleteListener<AuthResult>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "FragmentStatePagerAdapter" -> {
                String className = ComponentCodeGenerator.getAdapterClassName(targetId + "Fragment", false);
                yield "public class " + className + " extends FragmentStatePagerAdapter {\r\n" +
                        "// This class is deprecated, you should migrate to ViewPager2:\r\n" +
                        "// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2\r\n" +
                        "Context context;\r\n" +
                        "int tabCount;\r\n" +
                        "\r\n" +
                        "public " + className + "(Context context, FragmentManager manager) {\r\n" +
                        "super(manager);\r\n" +
                        "this.context = context;\r\n" +
                        "}\r\n" +
                        "\r\n" +
                        "public void setTabCount(int tabCount) {\r\n" +
                        "this.tabCount = tabCount;\r\n" +
                        "}\r\n" +
                        "\r\n" +
                        "@Override\r\n" +
                        "public int getCount() {\r\n" +
                        "return tabCount;\r\n" +
                        "}\r\n" +
                        "\r\n" +
                        listenerLogic + "\r\n" +
                        "}";
            }
            case "OnTimeSetListener" ->
                    targetId + "_listener = new TimePickerDialog.OnTimeSetListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "OnFailureListener" ->
                    targetId + "_onFailureLink = new OnFailureListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "authUpdatePasswordComplete" ->
                    targetId + "_updatePasswordListener = new OnCompleteListener<Void>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "OnGridItemClickListener" ->
                    targetId + ".setOnItemClickListener(new AdapterView.OnItemClickListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnRecyclerScrollListener" ->
                    targetId + ".addOnScrollListener(new RecyclerView.OnScrollListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnTimeChangeListener" ->
                    targetId + ".setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "authDeleteUserComplete" ->
                    targetId + "_deleteUserListener = new OnCompleteListener<Void>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "authUpdateProfileComplete" ->
                    targetId + "_updateProfileListener = new OnCompleteListener<Void>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "OnPageChangeListener" ->
                    targetId + ".addOnPageChangeListener(new ViewPager.OnPageChangeListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnErrorListener" ->
                    targetId + ".setOnErrorListener(new MediaPlayer.OnErrorListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "authEmailVerificationSent" ->
                    targetId + "_emailVerificationSentListener = new OnCompleteListener<Void>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "authUpdateEmailComplete" ->
                    targetId + "_updateEmailListener = new OnCompleteListener<Void>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "OnPreparedListener" ->
                    targetId + ".setOnPreparedListener(new MediaPlayer.OnPreparedListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnNavigationItemSelected" ->
                    targetId + ".setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnLetterSelectedListener" ->
                    targetId + ".setOnLetterSelectedListener(new WaveSideBar.OnLetterSelectedListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnRatingBarChangeListener" ->
                    targetId + ".setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnTabSelectedListener" ->
                    targetId + ".addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnDateChangeListener" -> "Calendar _calendar = Calendar.getInstance();\r\n" +
                    targetId + ".init(_calendar.get(Calendar.YEAR), _calendar.get(Calendar.MONTH), " +
                    "_calendar.get(Calendar.DAY_OF_MONTH), new DatePicker.OnDateChangedListener() {\r\n" +
                    listenerLogic + "\r\n" +
                    "});";
            case "OnCompleteListenerFCM" ->
                    targetId + "_onCompleteListener = new OnCompleteListener<String>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "PatternLockViewListener" ->
                    targetId + ".addPatternLockListener(new PatternLockViewListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "OnGridItemLongClickListener" ->
                    targetId + ".setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {\r\n" +
                            listenerLogic + "\r\n" +
                            "});";
            case "googleSignInListener" ->
                    targetId + "_googleSignInListener = new OnCompleteListener<AuthResult>() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "sqliteErrorHandler" ->
                    "private void _" + targetId + "_onSQLiteError(String _errorMessage) {\r\n" +
                            listenerLogic + "\r\n" +
                            "}";
            case "interstitialAdLoadCallback" ->
                    "_" + targetId + "_interstitial_ad_load_callback = new InterstitialAdLoadCallback() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "fullScreenContentCallback" ->
                    "_" + targetId + "_full_screen_content_callback = new FullScreenContentCallback() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "bannerAdViewListener" -> targetId + ".setAdListener(new AdListener() {\r\n" +
                    listenerLogic + "\r\n" +
                    "});";
            case "rewardedAdLoadCallback" ->
                    "_" + targetId + "_rewarded_ad_load_callback = new RewardedAdLoadCallback() {\r\n" +
                            listenerLogic + "\r\n" +
                            "};";
            case "onUserEarnedRewardListener" ->
                    "_" + targetId + "_on_user_earned_reward_listener = new OnUserEarnedRewardListener() {\r\n" +
                            "@Override\r\npublic void onUserEarnedReward(RewardItem _param1) {\r\n" +
                            "int _rewardAmount = _param1.getAmount();\r\n" +
                            "String _rewardType = _param1.getType();\r\n" +
                            listenerLogic + "\r\n" +
                            "}\r\n};";
            default -> EventsHandler.getListenerCode(listenerName, targetId, listenerLogic);
        };
    }

    public static String getExtraEventBlocks(String eventName) {
        return switch (eventName) {
            case "onUpdateProfileComplete", "onEmailVerificationSent", "onDeleteUserComplete",
                 "onUpdateEmailComplete", "onGoogleSignIn", "signInWithPhoneAuthComplete",
                 "onUpdatePasswordComplete" -> "%b.success %s.errorMessage";
            case "onScrolled" -> "%d.firstVisibleItem %d.visibleItemCount %d.totalItemCount";
            case "onDateChanged" -> "%d.year %d.month %d.day";
            case "onFailureLink" -> "%s.errorMessage";
            case "onNavigationItemSelected" -> "%d.itemId";
            case "onDateSet" -> "%m.datepicker.datePicker %d.year %d.month %d.day";
            case "onQueryTextChanged", "onQueryTextSubmit" -> "%s.charSeq";
            case "onError" -> "%d.what %d.extra";
            case "onVerificationCompleted" -> "%m.PhoneAuthCredential.credential";
            case "onRecyclerScrollChanged" -> "%d.scrollState";
            case "onRecyclerScrolled" -> "%d.offsetX %d.offsetY";
            case "onSuccessLink" -> "%s.link";
            case "onPageScrolled" -> "%d.position %d.positionOffset %d.positionOffsetPixels";
            case "onVerificationFailed" -> "%s.exception";
            case "onAccountPicker" -> "%m.GoogleSignInAccount.task";
            case "onTimeSet" -> "%d.hour %d.minute";
            case "onPageChanged" -> "%d.scrollState";
            case "onRatingChanged" -> "%d.value";
            case "onPatternLockProgress" -> "%m.listStr.pattern";
            case "onOptionsItemSelected" -> "%d.id %s.title";
            case "onPatternLockComplete" -> "%m.listStr.pattern";
            case "onTabSelected", "onTabReselected", "onTabAdded", "onTabUnselected",
                 "onFragmentAdded" -> "%d.position";
            case "onLetterSelected" -> "%s.index";
            case "onPageSelected" -> "%m.listMap.data %d.position";
            case "onCompleteRegister" -> "%b.success %s.token %s.errorMessage";
            case "onCodeSent" -> "%s.verificationId %m.FirebasePhoneAuth.token";
            case "onTimeChanged" -> "%d.hour %d.minute";
            case "onScrollChanged" -> "%d.scrollState";
            case "onBannerAdFailedToLoad", "onRewardAdFailedToLoad", "onInterstitialAdFailedToLoad",
                 "onAdFailedToShowFullScreenContent" -> "%d.errorCode %s.errorMessage";
            case "onSQLiteError" -> "%s.errorMessage";
            default -> EventsHandler.getBlocks(eventName);
        };
    }

    public static void addExtraComponentEvents(ClassInfo classInfo, ArrayList<String> list) {
        if (classInfo.matchesType("RewardedVideoAd")) {
            list.add("onRewardAdLoaded");
            list.add("onRewardAdFailedToLoad");
            list.add("onUserEarnedReward");
            list.add("onAdDismissedFullScreenContent");
            list.add("onAdFailedToShowFullScreenContent");
            list.add("onAdShowedFullScreenContent");
        }
        if (classInfo.matchesType("FragmentAdapter")) {
            list.add("onTabAdded");
            list.add("onFragmentAdded");
        }
        if (classInfo.matchesType("TimePickerDialog")) {
            list.add("onTimeSet");
        }
        if (classInfo.matchesType("DatePickerDialog")) {
            list.add("onDateSet");
        }
        if (classInfo.matchesType("FirebaseAuth")) {
            list.add("onUpdateEmailComplete");
            list.add("onUpdatePasswordComplete");
            list.add("onEmailVerificationSent");
            list.add("onDeleteUserComplete");
            list.add("signInWithPhoneAuthComplete");
            list.add("onUpdateProfileComplete");
            list.add("onGoogleSignIn");
        }
        if (classInfo.matchesType("FirebasePhoneAuth")) {
            list.add("onVerificationCompleted");
            list.add("onVerificationFailed");
            list.add("onCodeSent");
        }
        if (classInfo.matchesType("FirebaseCloudMessage")) {
            list.add("onCompleteRegister");
        }
        if (classInfo.matchesType("FirebaseGoogleLogin")) {
            list.add("onAccountPicker");
            list.add("onAccountPickerCancelled");
        }
        EventsHandler.addEvents(classInfo, list);
    }

    public static String getExtraEventSpec(String targetId, String eventName) {
        return switch (eventName) {
            case "onUpdateProfileComplete", "onEmailVerificationSent", "onDeleteUserComplete",
                 "onUpdateEmailComplete", "onGoogleSignIn", "onUpdatePasswordComplete",
                 "signInWithPhoneAuthComplete" ->
                    "When " + targetId + " " + eventName + " %b.success %s.errorMessage";
            case "onScrolled" ->
                    "When " + targetId + " " + eventName + " %d.firstVisibleItem %d.visibleItemCount %d.totalItemCount";
            case "onDateChanged", "onDateSet" ->
                    "When " + targetId + " " + eventName + " %d.year %d.month %d.day";
            case "onFailureLink" -> "When " + targetId + " " + eventName + " %s.errorMessage";
            case "onNavigationItemSelected" -> "When " + targetId + " " + eventName + " %d.itemId";
            case "onPrepared", "onCompletion", "onPatternLockCleared", "onAccountPickerCancelled",
                 "onPatternLockStarted" -> "When " + targetId + " " + eventName;
            case "onSaveInstanceState", "onCreateOptionsMenu", "onCreateContextMenu",
                 "onRestoreInstanceState", "onContextItemSelected" -> "When " + eventName;
            case "onQueryTextChanged", "onQueryTextSubmit" ->
                    "When " + targetId + " " + eventName + " %s.charSeq";
            case "onError" -> "When " + targetId + " " + eventName + " %d.what %d.extra";
            case "onVerificationCompleted" ->
                    "When " + targetId + " " + eventName + " %m.PhoneAuthCredential.credential";
            case "onRecyclerScrollChanged" ->
                    "When " + " " + targetId + " " + eventName + " %d.scrollState";
            case "onRecyclerScrolled" ->
                    "When " + " " + targetId + " " + eventName + " %d.offsetX %d.offsetY";
            case "onSuccessLink" -> "When " + targetId + " " + eventName + " %s.link";
            case "onPageScrolled" ->
                    "When " + targetId + " " + eventName + " %d.position %d.positionOffset %d.positionOffsetPixels";
            case "onVerificationFailed" -> "When " + targetId + " " + eventName + " %s.exception";
            case "onAccountPicker" ->
                    "When " + targetId + " " + eventName + " %m.GoogleSignInAccount.task";
            case "onFragmentAdded" -> "Fragment getItem %d.position";
            case "onTimeSet" -> "When " + targetId + " " + eventName + " %d.hour %d.minute";
            case "onPageChanged" -> "When " + targetId + " onPageScrollStateChanged %d.scrollState";
            case "onRatingChanged" -> "When " + targetId + " " + eventName + " %d.value";
            case "onPatternLockProgress", "onPatternLockComplete" ->
                    "When " + targetId + " " + eventName + " %m.listStr.pattern";
            case "onOptionsItemSelected" -> "When " + targetId + " %d.id %s.title";
            case "onTabSelected", "onTabUnselected", "onTabReselected", "onPageSelected" ->
                    targetId + ": " + eventName + " %d.position";
            case "onLetterSelected" -> "When " + targetId + " " + eventName + " %s.index";
            case "onTabAdded" -> "CharSequence getPageTitle %d.position";
            case "onCompleteRegister" ->
                    "When " + targetId + " " + eventName + " %b.success %s.token %s.errorMessage";
            case "onCodeSent" ->
                    "When " + targetId + " " + eventName + " %s.verificationId %m.FirebasePhoneAuth.token";
            case "onTimeChanged" -> "When " + targetId + " " + eventName + " %d.hour %d.minute";
            case "onScrollChanged" -> "When " + targetId + ": " + eventName + " %d.scrollState";
            case "onBannerAdFailedToLoad", "onInterstitialAdFailedToLoad", "onRewardAdFailedToLoad",
                 "onAdFailedToShowFullScreenContent" ->
                    targetId + ": " + eventName + " %d.errorCode %s.errorMessage";
            case "onUserEarnedReward" ->
                    targetId + ": " + eventName + " %d.rewardAmount %s.rewardType";
            case "onInterstitialAdLoaded", "onBannerAdLoaded" -> targetId + ": onAdLoaded";
            case "onAdDismissedFullScreenContent", "onAdShowedFullScreenContent",
                 "onRewardAdLoaded" -> targetId + ": " + eventName;
            case "onBannerAdOpened" -> targetId + ": onAdOpened";
            case "onBannerAdClicked" -> targetId + ": onAdClicked";
            case "onBannerAdClosed" -> targetId + ": onAdClosed";
            case "onSQLiteError" -> "When " + targetId + " onSQLiteError %s.errorMessage";
            default -> EventsHandler.getSpec(targetId, eventName);
        };
    }

    public static String buildMethodWithFallbackReturn(String template, String logicCode, String returnValue) {
        String fallbackReturn = String.format("return %s;", returnValue);
        String finalCode;

        if (logicCode.isEmpty()) {
            finalCode = fallbackReturn;
        } else {
            boolean missingReturn = new BlockReturnAnalyzer().hasAnyMissingReturn(logicCode);
            finalCode = missingReturn ? logicCode + "\r\n" + fallbackReturn : logicCode;
        }

        return String.format(template, finalCode);
    }

}
