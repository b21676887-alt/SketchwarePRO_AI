package pro.sketchware.core.codegen;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Arrays;

import pro.sketchware.core.codegen.EventsHandler;
import pro.sketchware.core.codegen.EventCodeGenerator;
import pro.sketchware.util.FileUtil;

public class ComponentExtraCode {

    public final StringBuilder listenerCodeBuilder;
    public final EventCodeGenerator eventCodeGenerator;

    public ComponentExtraCode(EventCodeGenerator h, StringBuilder st) {
        listenerCodeBuilder = st;
        eventCodeGenerator = h;
    }

    public void appendListenerCode(String listenerCode) {
        // Aldi's original Components
        if (listenerCode.contains("DatePickerFragment")) {
            eventCodeGenerator.eventListenerCode = listenerCode;
            return;
        }
        if (listenerCode.contains("FragmentStatePagerAdapter")) {
            String temp = eventCodeGenerator.eventLogic;
            if (temp.isEmpty()) {
                eventCodeGenerator.eventLogic = listenerCode;
            } else {
                eventCodeGenerator.eventLogic = temp.concat("\r\n\r\n").concat(listenerCode);
            }
            return;
        }
        if (listenerCode.contains("extends AsyncTask<String, Integer, String>")) {
            String temp = eventCodeGenerator.eventLogic;
            if (temp.isEmpty()) {
                eventCodeGenerator.eventLogic = listenerCode;
            } else {
                eventCodeGenerator.eventLogic = temp.concat("\r\n\r\n").concat(listenerCode);
            }
            return;
        }
        if (listenerCode.contains("_onSQLiteError")) {
            String temp = eventCodeGenerator.eventLogic;
            if (temp.isEmpty()) {
                eventCodeGenerator.eventLogic = listenerCode;
            } else {
                eventCodeGenerator.eventLogic = temp.concat("\r\n\r\n").concat(listenerCode);
            }
            return;
        }

        // Hilal's components
        String path = EventsHandler.CUSTOM_LISTENER_FILE_PATH;
        try {
            if (FileUtil.isExistFile(path) && !FileUtil.readFile(path).isEmpty() && !FileUtil.readFile(path).equals("[]")) {
                JSONArray arr = new JSONArray(FileUtil.readFile(path));
                if (arr.length() > 0) {
                    for (int i = 0; i < arr.length(); i++) {
                        String c = arr.getJSONObject(i).getString("code");
                        String f = getFirstLine(c);
                        if (!arr.getJSONObject(i).isNull("s") && listenerCode.contains(f)) {
                            String q = arr.getJSONObject(i).getString("s");
                            if (q.equals("true")) {
                                String temp = eventCodeGenerator.eventLogic;
                                if (temp.isEmpty()) {
                                    eventCodeGenerator.eventLogic = listenerCode.replace(f, "");
                                    return;
                                } else {
                                    eventCodeGenerator.eventLogic = temp.concat("\r\n\r\n").concat(listenerCode.replace(f, ""));
                                    return;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (listenerCodeBuilder.length() > 0 && !listenerCode.isEmpty()) {
                listenerCodeBuilder.append("\r\n");
                listenerCodeBuilder.append("\r\n");
                listenerCodeBuilder.append(listenerCode);
            }
        }


        ///others
        if (listenerCodeBuilder.length() > 0 && !listenerCode.isEmpty()) {
            listenerCodeBuilder.append("\r\n");
            listenerCodeBuilder.append("\r\n");
        }
        listenerCodeBuilder.append(listenerCode);
    }

    public String getFirstLine(String con) {
        ArrayList<String> list = new ArrayList<>(Arrays.asList(con.split("\n")));
        if (!list.isEmpty()) {
            for (int i = 0; i < list.size(); i++) {
                String a = list.get(i);
                if (!a.isEmpty()) {
                    return a.trim();
                }
            }
        }
        return "qTHwdyRjVoEqNjuXx";
    }
}
