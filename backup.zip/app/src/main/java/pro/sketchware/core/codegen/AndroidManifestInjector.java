package pro.sketchware.core.codegen;

import static pro.sketchware.util.GsonUtils.getGson;

import com.google.gson.JsonParseException;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.SketchwareUtil;
import pro.sketchware.util.xml.XmlBuilder;

public class AndroidManifestInjector {

    public static File getPathAndroidManifestAttributeInjection(String sc_id) {
        return new File(SketchwarePaths.getAndroidManifestAttributesPath(sc_id));
    }

    public static File getPathAndroidManifestLauncherActivity(String sc_id) {
        return new File(SketchwarePaths.getAndroidManifestLauncherActivityPath(sc_id));
    }

    public static File getPathAndroidManifestActivitiesComponents(String sc_id) {
        return new File(SketchwarePaths.getAndroidManifestActivitiesComponentsPath(sc_id));
    }

    public static File getPathAndroidManifestAppComponents(String sc_id) {
        return new File(SketchwarePaths.getAndroidManifestAppComponentsPath(sc_id));
    }

    private static ArrayList<HashMap<String, Object>> readAndroidManifestAttributeInjections(String sc_id) {
        ArrayList<HashMap<String, Object>> attributes;

        parseAttributes:
        {
            String errorMessage;

            try {
                File injections = getPathAndroidManifestAttributeInjection(sc_id);

                if (injections.exists()) {
                    attributes = getGson().fromJson(FileUtil.readFile(injections.getAbsolutePath()), Helper.TYPE_MAP_LIST);

                    if (attributes == null) {
                        errorMessage = "result == null";
                        // fall-through for shared error handling
                    } else {
                        break parseAttributes;
                    }
                } else {
                    return new ArrayList<>();
                }
            } catch (JsonParseException e) {
                errorMessage = e.toString();
                // fall-through for shared error handling
            }

            attributes = new ArrayList<>();
            SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_parse_failed), errorMessage));
        }

        return attributes;
    }

    public static void injectManifestPermissions(XmlBuilder manifestRoot, String sc_id) {
        ArrayList<HashMap<String, Object>> attributes = readAndroidManifestAttributeInjections(sc_id);

        for (int i = 0; i < attributes.size(); i++) {
            HashMap<String, Object> attribute = attributes.get(i);
            Object name = attribute.get("name");

            if (name instanceof String) {
                Object value = attribute.get("value");

                if (value instanceof String) {
                    if ("_application_permissions".equals(name)) {
                        XmlBuilder usesPermissionTag = new XmlBuilder("uses-permission");
                        usesPermissionTag.addAttributeValue((String) value);
                        manifestRoot.addChildNode(usesPermissionTag);
                    }
                } else {
                    SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_value), i + 1));
                }
            } else {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_name), i + 1));
            }
        }
    }

    public static void injectApplicationAttributes(XmlBuilder applicationTag, String sc_id) {
        applyApplicationAttributeInjections(applicationTag, sc_id);
    }

    public static boolean injectActivityAttributes(XmlBuilder activityTag, String sc_id, String actName) {
        ArrayList<HashMap<String, Object>> attributes = readAndroidManifestAttributeInjections(sc_id);
        int javaIdx = actName.indexOf(".java");
        String className = javaIdx >= 0 ? actName.substring(0, javaIdx) : actName;

        for (int i = 0; i < attributes.size(); i++) {
            HashMap<String, Object> attribute = attributes.get(i);
            Object name = attribute.get("name");

            if (name instanceof String) {
                if (className.equals(name)) {
                    applyActivityAttributeInjections(activityTag, sc_id, actName);
                    return true;
                }
            } else {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_name), i + 1));
            }
        }

        return false;
    }

    public static boolean isActivityThemeUsed(String projectId, String actName) {
        return isActivityAttributeUsed("android:theme", projectId, actName);
    }

    public static boolean isActivityOrientationUsed(String projectId, String actName) {
        return isActivityAttributeUsed("android:screenOrientation", projectId, actName);
    }

    public static boolean isActivityKeyboardUsed(String projectId, String actName) {
        return isActivityAttributeUsed("android:windowSoftInputMode", projectId, actName);
    }

    public static boolean isActivityExportedUsed(String sc_id, String activityName) {
        return isActivityAttributeUsed("android:exported", sc_id, activityName);
    }

    public static boolean isActivityAttributeUsed(String attribute, String sc_id, String activityName) {
        ArrayList<HashMap<String, Object>> attributes = readAndroidManifestAttributeInjections(sc_id);
        int javaIdx = activityName.indexOf(".java");
        String className = javaIdx >= 0 ? activityName.substring(0, javaIdx) : activityName;

        for (int i = 0; i < attributes.size(); i++) {
            HashMap<String, Object> attributeMap = attributes.get(i);
            Object name = attributeMap.get("name");

            if (name instanceof String) {
                if (className.equals(name) || "_apply_for_all_activities".equals(name)) {
                    Object value = attributeMap.get("value");

                    if (value instanceof String) {
                        if (((String) value).contains(attribute)) {
                            return true;
                        }
                    } else {
                        SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_value), i + 1));
                    }
                }
            } else {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_name), i + 1));
            }
        }

        return false;
    }

    public static String getLauncherActivity(String projectId) {
        File launcherActivityFile = getPathAndroidManifestLauncherActivity(projectId);

        if (launcherActivityFile.exists()) {
            String launcherActivity = FileUtil.readFile(launcherActivityFile.getAbsolutePath());

            if (!launcherActivity.contains(" ") && !launcherActivity.contains(".")) {
                return launcherActivity;
            }
        }

        return "main";
    }

    public static void setLauncherActivity(String projectId, String launcherActivityName) {
        FileUtil.writeFile(getPathAndroidManifestLauncherActivity(projectId).getAbsolutePath(),
                launcherActivityName);
    }

    public static String injectCustomComponents(String manifestXml, String projectId) {
        ArrayList<String> manifestLines = new ArrayList<>(Arrays.asList(manifestXml.split("\n")));

        String path = getPathAndroidManifestActivitiesComponents(projectId).getAbsolutePath();
        if (FileUtil.isExistFile(path)) {
            ArrayList<HashMap<String, Object>> data;
            try {
                data = getGson().fromJson(FileUtil.readFile(path), Helper.TYPE_MAP_LIST);
            } catch (JsonParseException e) {
                return manifestXml;
            }
            if (data == null) return manifestXml;
            for (int i = 0; i < data.size(); i++) {
                HashMap<String, Object> activityComponents = data.get(i);

                Object name = activityComponents.get("name");

                if (name instanceof String) {
                    Object value = activityComponents.get("value");

                    if (value instanceof String) {
                        if (!((String) value).trim().isEmpty()) {
                            for (int k = 3; k < manifestLines.size(); k++) {
                                String line = manifestLines.get(k);
                                String _line = manifestLines.get(k - 1);
                                if (line.contains("android:name=\"") && line.contains((String) name) && _line.contains("<activity")) {
                                    for (int q = k; q < manifestLines.size(); q++) {
                                        String v = manifestLines.get(q);
                                        String v2 = manifestLines.get(q - 1);
                                        if (v.matches("^\t\t<[a-zA-Z_-]+[^>]")) {
                                            boolean hasShortClosing = false, spaceBeforeClosing = false;

                                            if (v2.contains("\"/>")) {
                                                hasShortClosing = true;
                                            } else if (v2.contains("\" />")) {
                                                hasShortClosing = true;
                                                spaceBeforeClosing = true;
                                            }

                                            if (hasShortClosing) {
                                                manifestLines.set(q - 1, manifestLines.get(q - 1).replace(spaceBeforeClosing ? "\" />" : "\"/>", "\">"));
                                                manifestLines.set(q - 1, manifestLines.get(q - 1) + "\r\n" + value + "\r\n" + "</activity>");
                                            } else {
                                                manifestLines.set(q - 2, manifestLines.get(q - 2) + "\r\n" + value);
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        File appComponents = getPathAndroidManifestAppComponents(projectId);
        if (appComponents.exists()) {
            String appComponentsContent;
            if (!(appComponentsContent = FileUtil.readFile(appComponents.getAbsolutePath())).trim().isEmpty()) {
                String lastComponentLine = manifestLines.get(manifestLines.size() - 3);
                String mergedLine = lastComponentLine + "\r\n" + appComponentsContent;
                manifestLines.set(manifestLines.size() - 3, mergedLine);
            }
        }

        StringBuilder returnValue = new StringBuilder();
        for (String manifestLine : manifestLines) {
            returnValue.append("\n").append(manifestLine);
        }
        return returnValue.toString();
    }

    private static void applyApplicationAttributeInjections(XmlBuilder applicationTag, String sc_id) {
        ArrayList<HashMap<String, Object>> attributes = readAndroidManifestAttributeInjections(sc_id);

        boolean themeInjected = false;
        for (int i = 0; i < attributes.size(); i++) {
            HashMap<String, Object> attribute = attributes.get(i);
            Object name = attribute.get("name");

            if (name instanceof String) {
                if ("_application_attrs".equals(name)) {
                    Object value = attribute.get("value");

                    if (value instanceof String) {
                        applicationTag.addAttributeValue((String) value);

                        if (!themeInjected && ((String) value).contains("android:theme")) {
                            themeInjected = true;
                        }
                    } else {
                        SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_value), i + 1));
                    }
                }
            } else {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_name), i + 1));
            }
        }

        if (!themeInjected) {
            applicationTag.addAttributeValue("android:theme=\"@style/AppTheme\"");
        }
    }

    private static void applyActivityAttributeInjections(XmlBuilder activityTag, String sc_id, String actName) {
        ArrayList<HashMap<String, Object>> attributes = readAndroidManifestAttributeInjections(sc_id);
        int javaIdx = actName.indexOf(".java");
        String className = javaIdx >= 0 ? actName.substring(0, javaIdx) : actName;

        for (int i = 0; i < attributes.size(); i++) {
            HashMap<String, Object> attribute = attributes.get(i);
            Object name = attribute.get("name");

            if (name instanceof String) {
                if (className.equals(name) || "_apply_for_all_activities".equals(name)) {
                    Object value = attribute.get("value");

                    if (value instanceof String) {
                        activityTag.addAttributeValue((String) value);
                    } else {
                        SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_value), i + 1));
                    }
                }
            } else {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.manifest_error_invalid_name), i + 1));
            }
        }
    }
}
